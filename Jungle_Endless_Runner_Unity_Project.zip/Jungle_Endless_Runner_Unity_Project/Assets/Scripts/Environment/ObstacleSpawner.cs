using UnityEngine;

namespace JungleRunner
{
    /// <summary>Spawns obstacle rows, coin lines and power-ups on a segment. Always leaves at least one lane free per row.</summary>
    public class ObstacleSpawner : MonoBehaviour
    {
        public static ObstacleSpawner Instance { get; private set; }
        ObjectPool pool;
        static readonly ObstacleType[] LowTypes = { ObstacleType.Crate, ObstacleType.FallenLog, ObstacleType.ThornyBush, ObstacleType.BrokenBridge };
        static readonly ObstacleType[] HighTypes = { ObstacleType.StoneBarrier, ObstacleType.TreeRoots };
        static readonly ObstacleType[] BlockTypes = { ObstacleType.JungleRock, ObstacleType.JungleCart };

        public void Init(ObjectPool p)
        {
            Instance = this; pool = p;
            foreach (ObstacleType t in System.Enum.GetValues(typeof(ObstacleType)))
            {
                ObstacleType tt = t;
                pool.Register("Obs_" + t, () => ObstacleFactory.Build(tt));
                pool.Prewarm("Obs_" + t, 4);
            }
            pool.Register("Coin", CoinFactory.Build);
            pool.Prewarm("Coin", 60);
            foreach (PowerUpType t in System.Enum.GetValues(typeof(PowerUpType)))
            {
                PowerUpType tt = t;
                pool.Register("PU_" + t, () => PowerUpFactory.Build(tt));
                pool.Prewarm("PU_" + t, 1);
            }
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        static float LaneX(int lane) { return (lane - 1) * PlayerController.LaneWidth; }

        public void Populate(TrackSegment seg, float difficulty, bool safe)
        {
            const int slots = 5;
            float slotLen = TrackGenerator.SegmentLength / slots;
            float z0 = seg.transform.position.z;
            int powerSlot = (!safe && Random.value < 0.25f) ? Random.Range(1, slots) : -1;
            for (int s = 0; s < slots; s++)
            {
                float zc = z0 + slotLen * (s + 0.5f);
                int[] laneState = { -1, -1, -1 };   // -1 empty, else ObstacleKind
                bool obstacleRow = !safe && Random.value < Mathf.Lerp(0.6f, 0.92f, difficulty);
                if (obstacleRow)
                {
                    int free = Random.Range(0, 3);
                    bool two = Random.value < Mathf.Lerp(0.15f, 0.55f, difficulty);
                    int single = (free + Random.Range(1, 3)) % 3;
                    for (int lane = 0; lane < 3; lane++)
                    {
                        if (lane == free) continue;
                        if (!two && lane != single) continue;
                        float r = Random.value;
                        ObstacleType[] set = r < 0.4f ? LowTypes : (r < 0.7f ? HighTypes : BlockTypes);
                        ObstacleType type = set[Random.Range(0, set.Length)];
                        GameObject go = pool.Get("Obs_" + type, new Vector3(LaneX(lane), 0f, zc + Random.Range(-0.8f, 0.8f)), Quaternion.identity);
                        seg.Track(go);
                        laneState[lane] = (int)go.GetComponent<Obstacle>().kind;
                    }
                }
                int puLane = -1;
                if (s == powerSlot)
                {
                    puLane = FreeLane(laneState);
                    if (puLane >= 0)
                    {
                        PowerUpType[] bag = { PowerUpType.Magnet, PowerUpType.Shield, PowerUpType.SpeedBoost, PowerUpType.ScoreMultiplier, PowerUpType.CoinBonus, PowerUpType.Magnet, PowerUpType.Shield };
                        PowerUpType pt = bag[Random.Range(0, bag.Length)];
                        seg.Track(pool.Get("PU_" + pt, new Vector3(LaneX(puLane), 0f, zc), Quaternion.identity));
                    }
                }
                if (Random.value < 0.75f)
                {
                    int cl = Random.Range(0, 3);
                    for (int tries = 0; tries < 3 && (laneState[cl] == (int)ObstacleKind.Block || laneState[cl] == (int)ObstacleKind.High || cl == puLane); tries++) cl = (cl + 1) % 3;
                    if (laneState[cl] != (int)ObstacleKind.Block && laneState[cl] != (int)ObstacleKind.High && cl != puLane)
                        CoinLine(seg, LaneX(cl), zc - 3f, 5, laneState[cl] == (int)ObstacleKind.Low);
                }
            }
        }

        static int FreeLane(int[] st)
        {
            int start = Random.Range(0, 3);
            for (int i = 0; i < 3; i++) { int l = (start + i) % 3; if (st[l] < 0) return l; }
            return -1;
        }

        void CoinLine(TrackSegment seg, float x, float zStart, int count, bool arc)
        {
            for (int i = 0; i < count; i++)
            {
                float y = arc ? 0.9f + 1.0f * Mathf.Sin(Mathf.PI * i / (count - 1f)) : 0.9f;
                seg.Track(pool.Get("Coin", new Vector3(x, y, zStart + i * 1.5f), Quaternion.identity));
            }
        }
    }
}
