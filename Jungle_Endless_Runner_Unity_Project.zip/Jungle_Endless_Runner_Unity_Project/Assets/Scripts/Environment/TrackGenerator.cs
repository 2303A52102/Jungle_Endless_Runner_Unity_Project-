using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    /// <summary>Endless procedural track: builds 12 segment variants once, then recycles 7 active segments ahead of the player.</summary>
    public class TrackGenerator : MonoBehaviour
    {
        public const float SegmentLength = 40f;
        const int ActiveCount = 7;
        static readonly int[] VariantKinds = { 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3 };

        public bool Ready { get; private set; }
        Transform player;
        ObstacleSpawner spawner;
        ObjectPool pool;
        readonly List<TrackSegment> variants = new List<TrackSegment>();
        readonly Queue<TrackSegment> active = new Queue<TrackSegment>();
        float nextZ = -SegmentLength * 0.5f;
        int generated;
        Material water;

        public void Init(Transform p, ObstacleSpawner s, ObjectPool o) { player = p; spawner = s; pool = o; }

        public IEnumerator Build(System.Action<float> progress)
        {
            for (int i = 0; i < VariantKinds.Length; i++)
            {
                GameObject go = EnvironmentSpawner.BuildSegment(VariantKinds[i], 1000 + i * 7919);
                go.transform.SetParent(transform, false);
                TrackSegment seg = go.AddComponent<TrackSegment>();
                seg.kind = VariantKinds[i];
                go.SetActive(false);
                variants.Add(seg);
                if (progress != null) progress((i + 1f) / (VariantKinds.Length + 1f));
                yield return null;
            }
            for (int i = 0; i < ActiveCount; i++) SpawnNext();
            water = Mats.Water();
            Ready = true;
            if (progress != null) progress(1f);
        }

        void Update()
        {
            if (!Ready) return;
            if (player.position.z - active.Peek().StartZ > SegmentLength + 30f) Recycle();
            water.mainTextureOffset = new Vector2(Time.time * 0.05f, Time.time * 0.18f);
        }

        void Recycle()
        {
            TrackSegment old = active.Dequeue();
            old.ClearContent(pool);
            old.gameObject.SetActive(false);
            SpawnNext();
        }

        TrackSegment PickVariant()
        {
            int kind = 0;
            if (generated >= 3)
            {
                if (generated % 7 == 5) kind = 1;
                else { float r = Random.value; kind = r < 0.14f ? 2 : (r < 0.28f ? 3 : 0); }
            }
            List<TrackSegment> cand = new List<TrackSegment>();
            foreach (TrackSegment s in variants) if (s.kind == kind && !s.gameObject.activeSelf) cand.Add(s);
            if (cand.Count == 0) foreach (TrackSegment s in variants) if (!s.gameObject.activeSelf) cand.Add(s);
            return cand[Random.Range(0, cand.Count)];
        }

        void SpawnNext()
        {
            TrackSegment seg = PickVariant();
            seg.transform.position = new Vector3(0f, 0f, nextZ);
            seg.gameObject.SetActive(true);
            float diff = GameManager.Instance != null ? GameManager.Instance.Difficulty01 : 0f;
            spawner.Populate(seg, diff, generated < 3);
            active.Enqueue(seg);
            nextZ += SegmentLength;
            generated++;
        }

        public void ClearObstacles(float zMin, float zMax)
        {
            foreach (TrackSegment s in active) s.ClearObstacles(pool, zMin, zMax);
        }
    }
}
