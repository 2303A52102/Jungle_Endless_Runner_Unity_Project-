using UnityEngine;

namespace JungleRunner
{
    /// <summary>Builds one 40m jungle track segment from primitives.
    /// kind 0 = jungle path (maybe a hut), 1 = wooden bridge over a river, 2 = ancient temple ruins, 3 = waterfall cliff.
    /// All static decor is mesh-combined per material.</summary>
    public static class EnvironmentSpawner
    {
        const PrimitiveType Cube = PrimitiveType.Cube, Sph = PrimitiveType.Sphere, Cyl = PrimitiveType.Cylinder, Cap = PrimitiveType.Capsule;
        static Vector3 V(float x, float y, float z) { return new Vector3(x, y, z); }
        static float R(System.Random r, float a, float b) { return a + (float)r.NextDouble() * (b - a); }
        static GameObject P(Transform p, PrimitiveType t, Vector3 pos, Vector3 sc, string mat) { return Prim.Make(t, p, pos, sc, Pal.M(mat)); }
        static GameObject P(Transform p, PrimitiveType t, Vector3 pos, Vector3 sc, string mat, Vector3 e) { return Prim.Make(t, p, pos, sc, Pal.M(mat), e); }

        static void Slab(Transform root, Material m, float x0, float x1, float z0, float z1, float top, float thick)
        {
            Prim.Make(Cube, root, V((x0 + x1) * 0.5f, top - thick * 0.5f, (z0 + z1) * 0.5f), V(x1 - x0, thick, z1 - z0), m);
        }

        public static GameObject BuildSegment(int kind, int seed)
        {
            System.Random rng = new System.Random(seed);
            float L = TrackGenerator.SegmentLength;
            GameObject rootGO = new GameObject("Segment_k" + kind + "_" + seed);
            Transform root = rootGO.transform;

            BuildGround(root, kind, L, rng);

            // z sampler: bridge segments only decorate the two banks
            System.Func<float> Z = () =>
            {
                if (kind != 1) return R(rng, 0f, L);
                return rng.Next(2) == 0 ? R(rng, 0f, 5f) : R(rng, L - 5f, L);
            };

            int trees = kind == 1 ? 6 : 11;
            for (int i = 0; i < trees; i++)
            {
                bool right = (i % 2 == 0);
                float x = right ? R(rng, 6.5f, 30f) : -R(rng, 15.5f, 34f);
                if (kind == 3 && !right && x < -14f) x = -R(rng, 6f, 7.8f); // cliff on the left
                if (kind == 2 && right && x < 16f && x > 6f) x += 12f;       // keep temple area free
                if (rng.Next(4) == 0) Palm(root, x, Z(), rng); else Tree(root, x, Z(), rng, R(rng, 0.85f, 1.25f));
            }
            for (int i = 0; i < 14; i++)
            {
                bool right = (i % 2 == 0);
                float x = right ? R(rng, 4.8f, 10f) : -R(rng, 4.8f, 7.6f);
                Bush(root, x, Z(), rng);
            }
            for (int i = 0; i < 12; i++) Grass(root, (i % 2 == 0) ? R(rng, 4.3f, 8f) : -R(rng, 4.3f, 7.8f), Z(), rng);
            for (int i = 0; i < 9; i++) Fern(root, (i % 2 == 0) ? R(rng, 5f, 12f) : -R(rng, 4.8f, 7.6f), Z(), rng);
            for (int i = 0; i < 16; i++) Flowers(root, (i % 2 == 0) ? R(rng, 4.4f, 9f) : -R(rng, 4.4f, 7.5f), Z(), rng);
            for (int i = 0; i < 6; i++) Mushrooms(root, (i % 2 == 0) ? R(rng, 5f, 9f) : -R(rng, 4.8f, 7.5f), Z(), rng);
            for (int i = 0; i < 5; i++) Rock(root, (i % 2 == 0) ? R(rng, 4.6f, 12f) : -R(rng, 4.6f, 7.6f), Z(), rng, R(rng, 0.5f, 1.3f));
            if (kind != 1)
            {
                for (int i = 0; i < 4; i++) Rock(root, -R(rng, 8.5f, 13.5f), R(rng, 0f, L), rng, R(rng, 0.6f, 1.2f)); // river rocks
                Log(root, rng.Next(2) == 0 ? R(rng, 6f, 9f) : -R(rng, 5f, 7f), R(rng, 3f, L - 3f), rng);
                Monkey(root, R(rng, 6.5f, 8.5f), R(rng, 3f, L - 3f), rng);
            }
            // overhead canopy + hanging vines
            for (int i = 0; i < 5; i++)
            {
                float cx = R(rng, -9f, 9f), cz = Z();
                P(root, Sph, V(cx, R(rng, 10f, 12.5f), cz), V(R(rng, 5f, 8f), 2.2f, R(rng, 5f, 8f)), rng.Next(2) == 0 ? "LeafDark" : "Leaf1");
            }
            for (int i = 0; i < 8; i++)
            {
                float vx = (i % 2 == 0 ? 1 : -1) * R(rng, 4.5f, 6.5f), vz = Z(), len = R(rng, 3f, 6f);
                P(root, Cyl, V(vx, 10f - len * 0.5f, vz), V(0.07f, len * 0.5f, 0.07f), "Leaf1");
                P(root, Sph, V(vx, 10f - len, vz), V(0.3f, 0.2f, 0.3f), "Leaf3");
            }

            if (kind == 2) BuildRuins(root, rng, L);
            if (kind == 3) BuildWaterfall(root, rng);
            if (kind == 0 && rng.Next(2) == 0) Hut(root, R(rng, 11f, 13f), R(rng, 8f, 30f));
            if (kind != 1) for (int i = 0; i < 6; i++) Pebble(root, R(rng, -3.6f, 3.6f), R(rng, 0f, L), rng);

            MeshCombiner.Combine(rootGO);
            AddWildlife(root, rng, L);
            return rootGO;
        }

        // ------------------------------------------------------------ ground
        static void BuildGround(Transform root, int kind, float L, System.Random rng)
        {
            Material dirt = Pal.M("Dirt"), grass = Pal.M("Grass"), forest = Pal.M("Forest"), bed = Pal.M("RockDark"), water = Mats.Water();
            if (kind == 1)
            {
                float b0 = 6f, b1 = L - 6f;
                // banks (solid ground at both ends)
                Slab(root, dirt, -4f, 4f, 0f, b0, 0f, 1f); Slab(root, dirt, -4f, 4f, b1, L, 0f, 1f);
                Slab(root, grass, 4f, 12f, 0f, b0, 0f, 1f); Slab(root, grass, 4f, 12f, b1, L, 0f, 1f);
                Slab(root, grass, -12f, -4f, 0f, b0, 0f, 1f); Slab(root, grass, -12f, -4f, b1, L, 0f, 1f);
                Slab(root, forest, 12f, 45f, 0f, b0, 0f, 1f); Slab(root, forest, 12f, 45f, b1, L, 0f, 1f);
                Slab(root, forest, -45f, -12f, 0f, b0, 0f, 1f); Slab(root, forest, -45f, -12f, b1, L, 0f, 1f);
                // river under the bridge
                Slab(root, bed, -45f, 45f, b0, b1, -0.9f, 0.5f);
                Slab(root, water, -45f, 45f, b0, b1, -0.35f, 0.05f);
                // bridge planks
                int n = Mathf.FloorToInt((b1 - b0) / 1.0f);
                for (int i = 0; i < n; i++)
                    Prim.Make(Cube, root, V(0, -0.1f, b0 + 0.5f + i), V(8f, 0.2f, 0.92f), Pal.M(i % 2 == 0 ? "Wood" : "WoodDark"));
                Prim.Make(Cube, root, V(-3.2f, -0.45f, (b0 + b1) * 0.5f), V(0.4f, 0.4f, b1 - b0), Pal.M("Trunk"));
                Prim.Make(Cube, root, V(3.2f, -0.45f, (b0 + b1) * 0.5f), V(0.4f, 0.4f, b1 - b0), Pal.M("Trunk"));
                for (int i = 0; i <= 6; i++)
                    for (int s = -1; s <= 1; s += 2)
                    {
                        float z = b0 + i * ((b1 - b0) / 6f);
                        Prim.Make(Cyl, root, V(s * 3.95f, 0.6f, z), V(0.22f, 0.8f, 0.22f), Pal.M("Trunk"));
                        P(root, Sph, V(s * 3.95f, 1.45f, z), V(0.3f, 0.3f, 0.3f), "GlowOrange");
                    }
                for (int s = -1; s <= 1; s += 2)
                {
                    Prim.Make(Cube, root, V(s * 3.95f, 1.15f, (b0 + b1) * 0.5f), V(0.14f, 0.14f, b1 - b0), Pal.M("Rope"));
                    Prim.Make(Cube, root, V(s * 3.95f, 0.65f, (b0 + b1) * 0.5f), V(0.1f, 0.1f, b1 - b0), Pal.M("Rope"));
                }
                return;
            }
            Slab(root, dirt, -4f, 4f, 0f, L, 0f, 1f);                    // path
            Slab(root, grass, 4f, 12f, 0f, L, 0f, 1f);
            Slab(root, forest, 12f, 45f, 0f, L, 0f, 1f);
            Slab(root, grass, -8f, -4f, 0f, L, 0f, 1f);
            Slab(root, bed, -14f, -8f, 0f, L, -0.5f, 0.5f);               // river
            Slab(root, water, -14f, -8f, 0f, L, -0.3f, 0.05f);
            Slab(root, forest, -45f, -14f, 0f, L, 0f, 1f);
            // lane guide strips (dashed)
            for (int i = 0; i < 10; i++)
                for (int s = -1; s <= 1; s += 2)
                    Prim.Make(Cube, root, V(s * 1.25f, 0.012f, 1f + i * 4f), V(0.1f, 0.02f, 2f), Pal.M("DirtDark"));
        }

        // ------------------------------------------------------------ props
        static void Tree(Transform root, float x, float z, System.Random rng, float sc)
        {
            float h = R(rng, 7f, 12f) * sc, tw = R(rng, 0.45f, 0.8f) * sc;
            Transform t = Prim.Empty(root, "Tree", V(x, 0, z));
            string trunk = rng.Next(2) == 0 ? "Trunk" : "TrunkLight";
            P(t, Cyl, V(0, h * 0.5f, 0), V(tw, h * 0.5f, tw), trunk);
            for (int i = 0; i < 4; i++)
            {
                float a = (i * 90f + R(rng, 0, 40f)) * Mathf.Deg2Rad;
                float dx = Mathf.Cos(a), dz = Mathf.Sin(a);
                P(t, Cap, V(dx * tw * 0.8f, 0.45f, dz * tw * 0.8f), V(tw * 0.35f, 0.7f, tw * 0.35f), trunk, V(-dz * 40f, 0, dx * 40f));
            }
            string[] leaf = { "Leaf1", "Leaf2", "Leaf3", "LeafDark" };
            int blobs = 4 + rng.Next(2);
            for (int i = 0; i < blobs; i++)
            {
                float r = R(rng, 2.0f, 3.4f) * sc;
                P(t, Sph, V(R(rng, -1.3f, 1.3f), h * R(rng, 0.78f, 1.05f), R(rng, -1.3f, 1.3f)), V(r, r * 0.75f, r), leaf[rng.Next(4)]);
            }
            if (rng.Next(2) == 0)
            {
                float len = R(rng, 3f, 5f);
                P(t, Cyl, V(1.7f, h * 0.8f - len * 0.5f, 0.4f), V(0.06f, len * 0.5f, 0.06f), "Leaf1");
                P(t, Sph, V(1.7f, h * 0.8f - len, 0.4f), V(0.3f, 0.2f, 0.3f), "Leaf3");
            }
        }

        static void Palm(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Palm", V(x, 0, z));
            float lean = R(rng, -12f, 12f), h = R(rng, 6f, 9f);
            P(t, Cyl, V(Mathf.Sin(lean * Mathf.Deg2Rad) * h * 0.25f, h * 0.5f, 0), V(0.35f, h * 0.5f, 0.35f), "TrunkLight", V(0, 0, lean));
            Vector3 top = V(Mathf.Sin(-lean * Mathf.Deg2Rad) * -h * 0.5f, h, 0);
            for (int i = 0; i < 7; i++)
            {
                float ang = i * (360f / 7f);
                Vector3 dir = Quaternion.Euler(0, ang, 0) * Vector3.forward;
                P(t, Sph, top + dir * 1.2f + V(0, -0.2f, 0), V(0.45f, 0.08f, 2.6f), i % 2 == 0 ? "Leaf2" : "Leaf3", V(22f, ang, 0));
            }
            P(t, Sph, top + V(0.2f, -0.4f, 0.2f), V(0.3f, 0.3f, 0.3f), "Trunk");
        }

        static void Bush(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Bush", V(x, 0, z));
            string[] leaf = { "Leaf1", "Leaf2", "Leaf3" };
            for (int i = 0; i < 3; i++)
            {
                float r = R(rng, 0.7f, 1.3f);
                P(t, Sph, V(R(rng, -0.5f, 0.5f), r * 0.4f, R(rng, -0.5f, 0.5f)), V(r, r * 0.75f, r), leaf[rng.Next(3)]);
            }
        }

        static void Grass(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Grass", V(x, 0, z));
            for (int i = 0; i < 5; i++)
                P(t, Cap, V(R(rng, -0.2f, 0.2f), 0.3f, R(rng, -0.2f, 0.2f)), V(0.06f, 0.35f, 0.06f), rng.Next(2) == 0 ? "GrassLight" : "Leaf2", V(R(rng, -25f, 25f), 0, R(rng, -25f, 25f)));
        }

        static void Fern(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Fern", V(x, 0.1f, z));
            for (int i = 0; i < 6; i++)
            {
                float ang = i * 60f + R(rng, 0, 20f);
                Vector3 dir = Quaternion.Euler(0, ang, 0) * Vector3.forward;
                P(t, Sph, dir * 0.55f + V(0, 0.2f, 0), V(0.22f, 0.04f, 1.1f), "Leaf3", V(-25f, ang, 0));
            }
        }

        static void Flowers(Transform root, float x, float z, System.Random rng)
        {
            string[] cols = { "Red", "Yellow", "Purple", "Pink", "Orange", "White" };
            string c = cols[rng.Next(cols.Length)];
            Transform t = Prim.Empty(root, "Flowers", V(x, 0, z));
            for (int i = 0; i < 4; i++)
            {
                Vector3 o = V(R(rng, -0.4f, 0.4f), 0, R(rng, -0.4f, 0.4f));
                P(t, Cyl, o + V(0, 0.18f, 0), V(0.03f, 0.18f, 0.03f), "Leaf1");
                P(t, Sph, o + V(0, 0.38f, 0), V(0.2f, 0.12f, 0.2f), c);
                P(t, Sph, o + V(0, 0.4f, 0), V(0.07f, 0.07f, 0.07f), "Yellow");
            }
        }

        static void Mushrooms(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Mushrooms", V(x, 0, z));
            for (int i = 0; i < 3; i++)
            {
                float s = R(rng, 0.7f, 1.4f); Vector3 o = V(R(rng, -0.4f, 0.4f), 0, R(rng, -0.4f, 0.4f));
                P(t, Cyl, o + V(0, 0.12f * s, 0), V(0.12f * s, 0.12f * s, 0.12f * s), "White");
                P(t, Sph, o + V(0, 0.27f * s, 0), V(0.36f * s, 0.2f * s, 0.36f * s), rng.Next(3) == 0 ? "Orange" : "Red");
                P(t, Sph, o + V(0.08f * s, 0.34f * s, 0.05f * s), V(0.07f, 0.04f, 0.07f), "White");
                P(t, Sph, o + V(-0.07f * s, 0.33f * s, -0.07f * s), V(0.06f, 0.04f, 0.06f), "White");
            }
        }

        static void Rock(Transform root, float x, float z, System.Random rng, float s)
        {
            Transform t = Prim.Empty(root, "Rock", V(x, 0, z));
            P(t, Sph, V(0, 0.35f * s, 0), V(1.3f * s, 0.9f * s, 1.1f * s), rng.Next(2) == 0 ? "Rock" : "RockDark", V(0, R(rng, 0, 90f), 0));
            P(t, Sph, V(0.6f * s, 0.2f * s, 0.2f * s), V(0.7f * s, 0.5f * s, 0.6f * s), "RockDark");
            P(t, Sph, V(-0.1f * s, 0.7f * s, 0), V(0.8f * s, 0.2f * s, 0.7f * s), "Moss");
        }

        static void Pebble(Transform root, float x, float z, System.Random rng)
        {
            P(root, Sph, V(x, 0.03f, z), V(R(rng, 0.15f, 0.35f), 0.1f, R(rng, 0.15f, 0.3f)), "RockDark");
        }

        static void Log(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Log", V(x, 0, z));
            P(t, Cyl, V(0, 0.4f, 0), V(0.8f, 1.7f, 0.8f), "Trunk", V(0, R(rng, 0, 360f), 90f));
            P(t, Sph, V(0, 0.82f, 0), V(0.9f, 0.18f, 0.5f), "Moss");
        }

        static void Monkey(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Monkey", V(x, 0, z));
            P(t, Sph, V(0, 0.55f, 0), V(0.5f, 0.55f, 0.45f), "Monkey");
            P(t, Sph, V(0, 0.98f, 0.05f), V(0.36f, 0.34f, 0.34f), "Monkey");
            P(t, Sph, V(0, 0.95f, 0.2f), V(0.22f, 0.2f, 0.12f), "MonkeyFace");
            P(t, Sph, V(0.2f, 1.02f, 0.02f), V(0.14f, 0.14f, 0.08f), "MonkeyFace");
            P(t, Sph, V(-0.2f, 1.02f, 0.02f), V(0.14f, 0.14f, 0.08f), "MonkeyFace");
            P(t, Cap, V(0, 0.4f, -0.35f), V(0.08f, 0.45f, 0.08f), "Monkey", V(-55f, 0, 0));
            P(t, Sph, V(0.3f, 0.45f, 0.1f), V(0.14f, 0.35f, 0.14f), "Monkey");
            P(t, Sph, V(-0.3f, 0.45f, 0.1f), V(0.14f, 0.35f, 0.14f), "Monkey");
        }

        static void Hut(Transform root, float x, float z)
        {
            Transform t = Prim.Empty(root, "Hut", V(x, 0, z));
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sz = -1; sz <= 1; sz += 2)
                    P(t, Cyl, V(sx * 1.4f, 1f, sz * 1.4f), V(0.16f, 1f, 0.16f), "Trunk");
            P(t, Cube, V(0, 2.05f, 0), V(3.4f, 0.2f, 3.4f), "Wood");
            P(t, Cube, V(0, 3.05f, 0), V(3f, 1.8f, 3f), "WoodDark");
            P(t, Cube, V(-1.52f, 2.8f, 0), V(0.06f, 1.2f, 0.9f), "Door");
            P(t, Cube, V(-1.52f, 3.5f, 0.95f), V(0.06f, 0.5f, 0.5f), "Door");
            P(t, Cube, V(1.0f, 4.45f, 0), V(2.4f, 0.18f, 3.8f), "Thatch", V(0, 0, -32f));
            P(t, Cube, V(-1.0f, 4.45f, 0), V(2.4f, 0.18f, 3.8f), "Thatch", V(0, 0, 32f));
            for (int i = 0; i < 3; i++) P(t, Cube, V(-2.1f - i * 0.3f, 0.35f + (2 - i) * 0.55f - 0.1f, 0), V(0.4f, 0.12f, 1f), "Wood");
        }

        static void Pillar(Transform root, float x, float z, System.Random rng)
        {
            Transform t = Prim.Empty(root, "Pillar", V(x, 0, z));
            float h = R(rng, 2.5f, 4.5f);
            P(t, Cube, V(0, 0.2f, 0), V(1.1f, 0.4f, 1.1f), "StoneDark");
            P(t, Cyl, V(0, 0.4f + h * 0.5f, 0), V(0.6f, h * 0.5f, 0.6f), "Stone");
            P(t, Sph, V(0.1f, 0.4f + h, 0), V(0.7f, 0.2f, 0.6f), "Moss");
            P(t, Cyl, V(1.0f, 0.3f, 0.5f), V(0.55f, 0.7f, 0.55f), "StoneDark", V(0, 0, 90f));
            P(t, Cube, V(0, 0.4f + h * 0.4f, 0.31f), V(0.3f, 0.1f, 0.03f), "GlowGold");
        }

        static void BuildRuins(Transform root, System.Random rng, float L)
        {
            Vector3 c = V(15f, 0, 22f);
            P(root, Cube, c + V(0, 0.6f, 0), V(10f, 1.2f, 10f), "StoneDark");
            P(root, Cube, c + V(0, 1.8f, 0), V(8f, 1.2f, 8f), "Stone");
            P(root, Cube, c + V(0, 3.0f, 0), V(6f, 1.2f, 6f), "StoneDark");
            P(root, Cube, c + V(0, 4.2f, 0), V(4f, 1.2f, 4f), "Stone");
            P(root, Cube, c + V(0, 6f, 0), V(2.6f, 2.4f, 2.6f), "StoneDark");
            P(root, Cube, c + V(-1.32f, 5.6f, 0), V(0.06f, 1.5f, 1f), "Door");
            P(root, Cube, c + V(0, 7.4f, 0), V(3.2f, 0.4f, 3.2f), "Stone");
            P(root, Sph, c + V(0, 8.2f, 0), V(0.9f, 0.9f, 0.9f), "GlowGold");
            P(root, Sph, c + V(-2.5f, 1.3f, 3.5f), V(2.2f, 0.5f, 1.8f), "Moss");
            P(root, Sph, c + V(1.5f, 3.65f, -1.5f), V(1.8f, 0.4f, 1.4f), "Moss");
            for (int i = 0; i < 4; i++) P(root, Sph, c + V(-5.6f, 1.6f + i * 1.2f, -4f + i * 2.6f), V(0.35f, 0.35f, 0.35f), "GlowOrange");
            for (int i = 0; i < 3; i++)
            {
                Pillar(root, 5.4f, 6f + i * 12f, rng);
                Pillar(root, -5.4f, 12f + i * 12f, rng);
            }
            P(root, Cube, V(-6.5f, 0.6f, 5f), V(1f, 1.2f, 6f), "StoneDark");
            P(root, Cube, V(-6.5f, 1.4f, 5.5f), V(1f, 0.6f, 3f), "Stone");
        }

        static void BuildWaterfall(Transform root, System.Random rng)
        {
            P(root, Cube, V(-20f, 7f, 20f), V(9f, 14f, 24f), "RockDark");
            P(root, Cube, V(-18f, 5f, 12f), V(6f, 10f, 8f), "Rock");
            P(root, Cube, V(-19f, 13f, 28f), V(7f, 4f, 10f), "Rock");
            P(root, Sph, V(-18f, 14.2f, 20f), V(8f, 1.6f, 14f), "Moss");
            Prim.Make(Cube, root, V(-15.3f, 6.4f, 20f), V(0.5f, 13f, 3.6f), Mats.Fade("Waterfall", new Color(0.85f, 0.95f, 1f, 0.6f)));
            Prim.Make(Sph, root, V(-14.2f, 0.9f, 20f), V(5f, 2f, 5f), Mats.Fade("Mist", new Color(1f, 1f, 1f, 0.35f)));
            for (int i = 0; i < 5; i++) Rock(root, -R(rng, 9f, 13f), R(rng, 15f, 25f), rng, R(rng, 0.8f, 1.5f));
        }

        // ------------------------------------------------------------ wildlife (animated, not combined)
        static void AddWildlife(Transform root, System.Random rng, float L)
        {
            string[] cols = { "Orange", "Yellow", "Pink", "Purple", "Red" };
            for (int i = 0; i < 3; i++)
            {
                Transform b = Prim.Empty(root, "Butterfly", Vector3.zero);
                Material wm = Pal.M(cols[rng.Next(cols.Length)]);
                Prim.Make(Cap, b, Vector3.zero, V(0.04f, 0.1f, 0.04f), Pal.M("Black"), V(90, 0, 0));
                Transform wl = Prim.Empty(b, "WL", V(-0.03f, 0, 0)); Prim.Make(Cube, wl, V(-0.09f, 0, 0), V(0.18f, 0.01f, 0.14f), wm);
                Transform wr = Prim.Empty(b, "WR", V(0.03f, 0, 0)); Prim.Make(Cube, wr, V(0.09f, 0, 0), V(0.18f, 0.01f, 0.14f), wm);
                Flutter f = b.gameObject.AddComponent<Flutter>();
                f.wingL = wl; f.wingR = wr;
                f.center = V(R(rng, -7f, 7f), R(rng, 1f, 2.5f), R(rng, 3f, L - 3f));
                f.radius = R(rng, 1f, 2.5f); f.speed = R(rng, 0.7f, 1.4f); f.flapSpeed = 20f; f.flapAngle = 55f;
            }
            Transform bird = Prim.Empty(root, "Bird", Vector3.zero);
            string bc = rng.Next(2) == 0 ? "Red" : "GlowBlue";
            Prim.Make(Sph, bird, Vector3.zero, V(0.28f, 0.2f, 0.5f), Pal.M(bc));
            Prim.Make(Sph, bird, V(0, 0.06f, 0.28f), V(0.16f, 0.16f, 0.16f), Pal.M(bc));
            Prim.Make(Cube, bird, V(0, 0.04f, 0.4f), V(0.04f, 0.04f, 0.1f), Pal.M("Orange"));
            Transform bl = Prim.Empty(bird, "WL", V(-0.1f, 0.03f, 0)); Prim.Make(Cube, bl, V(-0.35f, 0, 0), V(0.7f, 0.02f, 0.28f), Pal.M(bc));
            Transform br = Prim.Empty(bird, "WR", V(0.1f, 0.03f, 0)); Prim.Make(Cube, br, V(0.35f, 0, 0), V(0.7f, 0.02f, 0.28f), Pal.M(bc));
            Flutter bf = bird.gameObject.AddComponent<Flutter>();
            bf.wingL = bl; bf.wingR = br; bf.center = V(R(rng, -4f, 4f), R(rng, 7f, 9f), L * 0.5f);
            bf.radius = R(rng, 8f, 14f); bf.speed = 0.35f; bf.flapSpeed = 9f; bf.flapAngle = 35f; bf.bobHeight = 1f;
        }
    }
}
