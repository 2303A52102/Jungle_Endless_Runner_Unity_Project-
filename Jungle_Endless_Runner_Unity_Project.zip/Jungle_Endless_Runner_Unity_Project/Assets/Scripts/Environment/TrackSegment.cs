using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    /// <summary>One pooled 40m track segment plus the pooled obstacles / coins / power-ups spawned on it.</summary>
    public class TrackSegment : MonoBehaviour
    {
        public int kind;
        readonly List<GameObject> content = new List<GameObject>();
        public float StartZ { get { return transform.position.z; } }

        public void Track(GameObject go)
        {
            PoolTag tag = go.GetComponent<PoolTag>();
            if (tag != null) tag.owner = this;
            content.Add(go);
        }

        public void ClearContent(ObjectPool pool)
        {
            for (int i = 0; i < content.Count; i++)
            {
                GameObject go = content[i];
                if (go == null || !go.activeSelf) continue;
                PoolTag tag = go.GetComponent<PoolTag>();
                if (tag == null || tag.owner != this) continue;
                pool.Release(go);
            }
            content.Clear();
        }

        public void ClearObstacles(ObjectPool pool, float zMin, float zMax)
        {
            for (int i = 0; i < content.Count; i++)
            {
                GameObject go = content[i];
                if (go == null || !go.activeSelf) continue;
                PoolTag tag = go.GetComponent<PoolTag>();
                if (tag == null || tag.owner != this || go.GetComponent<Obstacle>() == null) continue;
                float z = go.transform.position.z;
                if (z >= zMin && z <= zMax) pool.Release(go);
            }
        }
    }
}
