using UnityEngine;

namespace JungleRunner
{
    /// <summary>Camera-attached jungle atmosphere: sunlight rays through the canopy and drifting pollen / fireflies.</summary>
    public static class Atmosphere
    {
        public static void Attach(Camera cam)
        {
            Transform root = Prim.Empty(cam.transform, "Atmosphere", Vector3.zero);
            Material ray = Mats.Ray();
            float[] xs = { -11f, -6.5f, -2f, 3f, 7.5f, 12f };
            for (int i = 0; i < xs.Length; i++)
                Prim.Make(PrimitiveType.Quad, root, new Vector3(xs[i], 6f, 22f + (i % 2) * 4f), new Vector3(2.4f + (i % 3), 26f, 1f), ray, new Vector3(0f, 0f, 18f + (i % 3) * 7f));

            GameObject go = new GameObject("Pollen");
            go.transform.SetParent(cam.transform, false);
            go.transform.localPosition = new Vector3(0f, 2f, 17f);
            ParticleSystem ps = go.AddComponent<ParticleSystem>();
            ParticleSystem.MainModule m = ps.main;
            m.loop = true; m.prewarm = true; m.startLifetime = 7f;
            m.startSpeed = new ParticleSystem.MinMaxCurve(0.1f, 0.5f);
            m.startSize = new ParticleSystem.MinMaxCurve(0.05f, 0.16f);
            m.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.95f, 0.5f, 0.8f), new Color(0.8f, 1f, 0.6f, 0.6f));
            m.gravityModifier = -0.02f; m.maxParticles = 160;
            m.simulationSpace = ParticleSystemSimulationSpace.World;
            ParticleSystem.EmissionModule e = ps.emission; e.rateOverTime = 22f;
            ParticleSystem.ShapeModule sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(26f, 9f, 36f);
            go.GetComponent<ParticleSystemRenderer>().sharedMaterial = Mats.SpriteMat("Pollen", Mats.SoftCircle(), Color.white);
        }
    }
}
