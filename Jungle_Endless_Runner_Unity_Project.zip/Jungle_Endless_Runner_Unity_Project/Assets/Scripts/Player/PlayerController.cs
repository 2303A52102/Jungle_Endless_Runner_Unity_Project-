using UnityEngine;

namespace JungleRunner
{
    /// <summary>Auto-running three-lane controller: swipe / keyboard input, jump, slide, trigger-based collisions.</summary>
    [DisallowMultipleComponent]
    public class PlayerController : MonoBehaviour
    {
        public const float LaneWidth = 2.5f;
        const float JumpHeight = 2.2f, Gravity = -38f, SlideDuration = 0.75f, LaneSpeed = 22f, SwipeThreshold = 60f;
        const float StandHeight = 1.8f, SlideColHeight = 0.8f;

        public PlayerAnimation Anim { get; private set; }
        public bool IsDead { get; private set; }

        Rigidbody rb;
        CapsuleCollider capsule;
        GameObject shieldVisual;
        int lane = 1;
        float vy, slideTimer, invulnerable;
        bool grounded = true, sliding, queuedSlide, touchActive;
        Vector2 touchStart;

        void Awake()
        {
            rb = gameObject.AddComponent<Rigidbody>();
            rb.isKinematic = true; rb.useGravity = false;
            capsule = gameObject.AddComponent<CapsuleCollider>();
            capsule.direction = 1; capsule.radius = 0.35f;
            SetColliderHeight(StandHeight);
        }

        public void Init(PlayerAnimation anim)
        {
            Anim = anim;
            shieldVisual = Prim.Make(PrimitiveType.Sphere, transform, new Vector3(0, 0.95f, 0), new Vector3(2.1f, 2.3f, 2.1f),
                Mats.Fade("ShieldBubble", new Color(0.3f, 0.9f, 1f, 0.28f)));
            shieldVisual.SetActive(false);
        }

        void SetColliderHeight(float h) { capsule.height = h; capsule.center = new Vector3(0f, h * 0.5f, 0f); }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || !gm.IsPlaying || IsDead) return;
            float dt = Time.deltaTime;
            ReadInput();
            if (invulnerable > 0f) invulnerable -= dt;

            Vector3 p = transform.position;
            p.z += gm.Speed * dt;
            float targetX = (lane - 1) * LaneWidth;
            p.x = Mathf.MoveTowards(p.x, targetX, LaneSpeed * dt);
            if (!grounded)
            {
                vy += Gravity * dt;
                p.y += vy * dt;
                if (p.y <= 0f)
                {
                    p.y = 0f; vy = 0f; grounded = true;
                    AudioManager.Play(Sfx.Land, 0.5f);
                    if (queuedSlide) { queuedSlide = false; StartSlide(); }
                }
            }
            transform.position = p;
            if (sliding) { slideTimer -= dt; if (slideTimer <= 0f) EndSlide(); }

            bool shield = PowerUpManager.Instance != null && PowerUpManager.Instance.IsActive(PowerUpType.Shield);
            if (shieldVisual != null) shieldVisual.SetActive(shield || invulnerable > 0f);
            if (Anim != null)
            {
                Anim.lean = targetX - p.x;
                Anim.State = sliding ? PlayerState.Slide : (!grounded ? PlayerState.Jump : PlayerState.Run);
            }
        }

        // ---------------- input ----------------
        void ReadInput()
        {
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) ChangeLane(-1);
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) ChangeLane(1);
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W)) Jump();
            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) Slide();

            if (Input.touchCount > 0)
            {
                Touch t = Input.GetTouch(0);
                if (t.phase == TouchPhase.Began) { touchStart = t.position; touchActive = true; }
                else if (touchActive && (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary)) TrySwipe(t.position - touchStart);
                else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) touchActive = false;
            }
            else if (!Input.touchSupported)
            {
                if (Input.GetMouseButtonDown(0)) { touchStart = Input.mousePosition; touchActive = true; }
                else if (touchActive && Input.GetMouseButton(0)) TrySwipe((Vector2)Input.mousePosition - touchStart);
                if (Input.GetMouseButtonUp(0)) touchActive = false;
            }
        }

        void TrySwipe(Vector2 d)
        {
            if (d.magnitude < SwipeThreshold) return;
            touchActive = false;
            if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) ChangeLane(d.x > 0f ? 1 : -1);
            else if (d.y > 0f) Jump();
            else Slide();
        }

        // ---------------- actions ----------------
        void ChangeLane(int dir)
        {
            int n = Mathf.Clamp(lane + dir, 0, 2);
            if (n == lane) return;
            lane = n;
            AudioManager.Play(Sfx.Slide, 0.25f);
        }

        void Jump()
        {
            if (!grounded) return;
            if (sliding) EndSlide();
            vy = Mathf.Sqrt(-2f * Gravity * JumpHeight);
            grounded = false;
            AudioManager.Play(Sfx.Jump, 0.6f);
        }

        void Slide()
        {
            if (!grounded) { vy = -26f; queuedSlide = true; return; }
            if (sliding) return;
            StartSlide();
        }

        void StartSlide()
        {
            sliding = true; slideTimer = SlideDuration;
            SetColliderHeight(SlideColHeight);
            AudioManager.Play(Sfx.Slide, 0.5f);
        }

        void EndSlide() { sliding = false; SetColliderHeight(StandHeight); }

        // ---------------- collisions ----------------
        void OnTriggerEnter(Collider other)
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || !gm.IsPlaying || IsDead) return;
            Obstacle ob = other.GetComponent<Obstacle>();
            if (ob != null) { HitObstacle(ob); return; }
            Coin coin = other.GetComponent<Coin>();
            if (coin != null) { if (CoinManager.Instance != null) CoinManager.Instance.Collect(coin); return; }
            PowerUpPickup pu = other.GetComponent<PowerUpPickup>();
            if (pu != null)
            {
                if (PowerUpManager.Instance != null) PowerUpManager.Instance.Activate(pu.type, pu.transform.position + Vector3.up);
                ObjectPool.Instance.Release(pu.gameObject);
            }
        }

        void HitObstacle(Obstacle ob)
        {
            if (invulnerable > 0f) return;
            PowerUpManager pm = PowerUpManager.Instance;
            if (pm != null && pm.SpeedBoostActive) { Smash(ob); return; }
            if (pm != null && pm.ConsumeShield()) { invulnerable = 1.2f; Smash(ob); AudioManager.Play(Sfx.Hit, 0.5f); return; }
            Die();
        }

        void Smash(Obstacle ob)
        {
            Effects.Burst(ob.transform.position + Vector3.up, new Color(0.6f, 0.4f, 0.2f), 24);
            if (GameManager.Instance.Cam != null) GameManager.Instance.Cam.Shake(0.2f, 0.25f);
            ObjectPool.Instance.Release(ob.gameObject);
        }

        void Die()
        {
            IsDead = true;
            if (Anim != null) Anim.State = PlayerState.Dead;
            GameManager.Instance.EndRun();
        }

        public void Revive()
        {
            IsDead = false; sliding = false; queuedSlide = false; grounded = true; vy = 0f;
            SetColliderHeight(StandHeight);
            Vector3 p = transform.position; p.y = 0f; transform.position = p;
            invulnerable = 3f;
            if (Anim != null) Anim.State = PlayerState.Run;
        }
    }
}
