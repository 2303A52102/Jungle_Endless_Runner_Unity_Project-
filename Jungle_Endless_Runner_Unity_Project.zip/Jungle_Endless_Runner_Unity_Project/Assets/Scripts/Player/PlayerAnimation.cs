using UnityEngine;

namespace JungleRunner
{
    public enum PlayerState { Idle, Run, Jump, Slide, Dead }

    /// <summary>Procedural limb animation for the primitive explorer character.</summary>
    public class PlayerAnimation : MonoBehaviour
    {
        public Transform model, armL, armR, legL, legR;
        public PlayerState State = PlayerState.Run;
        public float lean;
        public bool useGameSpeed = true;

        void Update()
        {
            if (model == null) return;
            float dt = Time.deltaTime;
            float k = 1f - Mathf.Exp(-16f * dt);
            float speed = (useGameSpeed && GameManager.Instance != null) ? GameManager.Instance.Speed : 14f;
            Vector3 mPos = Vector3.zero;
            Quaternion mRot = Quaternion.Euler(0f, Mathf.Clamp(lean * 18f, -25f, 25f), 0f);
            float aL = 0f, aR = 0f, lL = 0f, lR = 0f;
            switch (State)
            {
                case PlayerState.Run:
                    float ph = Time.time * (9f + speed * 0.18f);
                    float s = Mathf.Sin(ph);
                    aL = s * 55f; aR = -s * 55f; lL = -s * 50f; lR = s * 50f;
                    mPos.y = Mathf.Abs(Mathf.Cos(ph)) * 0.07f;
                    break;
                case PlayerState.Idle:
                    aL = Mathf.Sin(Time.time * 2f) * 5f; aR = -aL;
                    break;
                case PlayerState.Jump:
                    aL = -150f; aR = -150f; lL = -40f; lR = 25f;
                    break;
                case PlayerState.Slide:
                    mPos = new Vector3(0f, 0.5f, 0f);
                    mRot = Quaternion.Euler(-75f, 0f, 0f);
                    aL = -140f; aR = -140f;
                    break;
                case PlayerState.Dead:
                    mPos = new Vector3(0f, 0.3f, 0f);
                    mRot = Quaternion.Euler(-85f, 0f, 0f);
                    aL = -30f; aR = 40f; lL = 10f; lR = -15f;
                    break;
            }
            model.localPosition = Vector3.Lerp(model.localPosition, mPos, k);
            model.localRotation = Quaternion.Slerp(model.localRotation, mRot, k);
            armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(aL, 0f, 0f), k);
            armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(aR, 0f, 0f), k);
            legL.localRotation = Quaternion.Slerp(legL.localRotation, Quaternion.Euler(lL, 0f, 0f), k);
            legR.localRotation = Quaternion.Slerp(legR.localRotation, Quaternion.Euler(lR, 0f, 0f), k);
        }
    }

    public static class PlayerFactory
    {
        static Vector3 V(float x, float y, float z) { return new Vector3(x, y, z); }

        public static PlayerController Create()
        {
            GameObject root = new GameObject("Player");
            PlayerAnimation anim = BuildModel(root.transform);
            PlayerController pc = root.AddComponent<PlayerController>();
            pc.Init(anim);
            return pc;
        }

        public static PlayerAnimation BuildModel(Transform parent)
        {
            PrimitiveType cube = PrimitiveType.Cube, sph = PrimitiveType.Sphere, cap = PrimitiveType.Capsule, cyl = PrimitiveType.Cylinder;
            Transform model = Prim.Empty(parent, "Model", Vector3.zero);
            Prim.Make(cube, model, V(0, 1.05f, 0), V(0.58f, 0.72f, 0.36f), Pal.M("Shirt"), true);
            Prim.Make(cube, model, V(0, 0.72f, 0), V(0.6f, 0.12f, 0.38f), Pal.M("Hat"), true);   // belt
            Prim.Make(cube, model, V(0, 1.08f, -0.29f), V(0.46f, 0.52f, 0.22f), Pal.M("WoodDark"), true); // backpack
            Prim.Make(sph, model, V(0, 1.68f, 0), V(0.4f, 0.42f, 0.4f), Pal.M("Skin"), true);
            Prim.Make(cyl, model, V(0, 1.82f, 0), V(0.62f, 0.03f, 0.62f), Pal.M("Hat"), true);      // hat brim
            Prim.Make(sph, model, V(0, 1.84f, 0), V(0.38f, 0.26f, 0.38f), Pal.M("Hat"), true);      // hat dome
            Prim.Make(sph, model, V(0.09f, 1.7f, 0.17f), V(0.06f, 0.06f, 0.06f), Pal.M("Black"));
            Prim.Make(sph, model, V(-0.09f, 1.7f, 0.17f), V(0.06f, 0.06f, 0.06f), Pal.M("Black"));
            Transform aL = Prim.Empty(model, "ArmL", V(-0.37f, 1.36f, 0));
            Transform aR = Prim.Empty(model, "ArmR", V(0.37f, 1.36f, 0));
            Transform lL = Prim.Empty(model, "LegL", V(-0.14f, 0.72f, 0));
            Transform lR = Prim.Empty(model, "LegR", V(0.14f, 0.72f, 0));
            foreach (Transform a in new Transform[] { aL, aR })
            {
                Prim.Make(cap, a, V(0, -0.27f, 0), V(0.17f, 0.3f, 0.17f), Pal.M("Shirt"), true);
                Prim.Make(sph, a, V(0, -0.58f, 0), V(0.16f, 0.16f, 0.16f), Pal.M("Skin"), true);
            }
            foreach (Transform l in new Transform[] { lL, lR })
            {
                Prim.Make(cap, l, V(0, -0.33f, 0), V(0.21f, 0.28f, 0.21f), Pal.M("Pants"), true);
                Prim.Make(cube, l, V(0, -0.68f, 0.05f), V(0.22f, 0.12f, 0.34f), Pal.M("Trunk"), true);
            }
            PlayerAnimation anim = parent.gameObject.AddComponent<PlayerAnimation>();
            anim.model = model; anim.armL = aL; anim.armR = aR; anim.legL = lL; anim.legR = lR;
            return anim;
        }
    }
}
