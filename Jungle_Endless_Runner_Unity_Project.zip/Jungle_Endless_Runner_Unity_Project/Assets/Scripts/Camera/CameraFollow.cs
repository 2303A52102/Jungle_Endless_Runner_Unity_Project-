using UnityEngine;

namespace JungleRunner
{
    /// <summary>Smooth third-person follow camera, slightly downward, with FOV kick on speed boost and crash shake.</summary>
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0f, 4.4f, -7.4f);
        public float lookAhead = 9f;
        Camera cam;
        Vector3 smooth;
        float shakeTime, shakeMag, baseFov = 62f;

        public void Init(Transform t)
        {
            target = t; cam = GetComponent<Camera>();
            smooth = t.position + offset;
            transform.position = smooth;
            transform.rotation = Quaternion.LookRotation(t.position + new Vector3(0, 1.2f, lookAhead) - smooth);
        }

        public void Shake(float magnitude, float duration) { shakeMag = magnitude; shakeTime = duration; }

        void LateUpdate()
        {
            if (target == null) return;
            float dt = Time.deltaTime;
            Vector3 tp = target.position;
            smooth.x = Mathf.Lerp(smooth.x, tp.x * 0.55f, 1f - Mathf.Exp(-8f * dt));
            smooth.y = Mathf.Lerp(smooth.y, offset.y + Mathf.Clamp(tp.y, 0f, 3f) * 0.35f, 1f - Mathf.Exp(-6f * dt));
            smooth.z = tp.z + offset.z;
            Vector3 shake = Vector3.zero;
            if (shakeTime > 0f) { shakeTime -= Time.unscaledDeltaTime; shake = Random.insideUnitSphere * shakeMag * Mathf.Clamp01(shakeTime); }
            transform.position = smooth + shake;
            Vector3 look = new Vector3(tp.x * 0.35f, 1.2f + tp.y * 0.2f, tp.z + lookAhead);
            Quaternion rot = Quaternion.LookRotation(look - smooth);
            transform.rotation = Quaternion.Slerp(transform.rotation, rot, 1f - Mathf.Exp(-10f * dt));
            if (cam != null && GameManager.Instance != null)
            {
                float f = baseFov + Mathf.Clamp((GameManager.Instance.Speed - 14f) * 0.35f, 0f, 14f);
                cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, f, 1f - Mathf.Exp(-4f * dt));
            }
        }
    }
}
