using UnityEngine;

namespace JungleRunner
{
    /// <summary>Pooled particle bursts (coin sparkle, obstacle smash, power-up pop).</summary>
    public class Effects : MonoBehaviour
    {
        public static Effects Instance { get; private set; }
        ParticleSystem[] systems;
        int next;

        void Awake()
        {
            Instance = this;
            systems = new ParticleSystem[12];
            Gradient g = new Gradient();
            g.SetKeys(new GradientColorKey[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new GradientAlphaKey[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
            for (int i = 0; i < systems.Length; i++)
            {
                GameObject go = new GameObject("FX" + i);
                go.transform.SetParent(transform, false);
                ParticleSystem ps = go.AddComponent<ParticleSystem>();
                ParticleSystem.MainModule main = ps.main;
                main.loop = true; main.playOnAwake = false;
                main.startLifetime = 0.7f;
                main.startSpeed = new ParticleSystem.MinMaxCurve(2.5f, 6f);
                main.startSize = new ParticleSystem.MinMaxCurve(0.12f, 0.3f);
                main.gravityModifier = 0.6f;
                main.simulationSpace = ParticleSystemSimulationSpace.World;
                main.maxParticles = 80;
                ParticleSystem.EmissionModule em = ps.emission; em.rateOverTime = 0f;
                ParticleSystem.ShapeModule sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Sphere; sh.radius = 0.15f;
                ParticleSystem.ColorOverLifetimeModule col = ps.colorOverLifetime; col.enabled = true; col.color = g;
                go.GetComponent<ParticleSystemRenderer>().sharedMaterial = Mats.SpriteMat("FX", Mats.SoftCircle(), Color.white);
                ps.Play();
                systems[i] = ps;
            }
        }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public static void Burst(Vector3 pos, Color color, int count = 14)
        {
            if (Instance == null) return;
            ParticleSystem ps = Instance.systems[Instance.next++ % Instance.systems.Length];
            ps.transform.position = pos;
            ParticleSystem.MainModule main = ps.main;
            main.startColor = color;
            ps.Emit(count);
        }
    }
}
