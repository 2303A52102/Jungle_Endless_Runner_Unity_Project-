using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace JungleRunner
{
    /// <summary>Single entry point placed in both scenes. Builds the whole game at runtime (camera, light, world, managers, UI).
    /// If a scene has no bootstrap (e.g. a blank scene), one is created automatically.</summary>
    public class GameBootstrap : MonoBehaviour
    {
        public enum Mode { Menu, Gameplay }
        public Mode mode = Mode.Menu;
        static Material[] shaderHolders;   // keeps shader variants referenced in builds

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void EnsureBootstrap()
        {
            if (FindObjectOfType<GameBootstrap>() != null) return;
            GameBootstrap b = new GameObject("GameBootstrap").AddComponent<GameBootstrap>();
            b.mode = SceneManager.GetActiveScene().name == "Gameplay" ? Mode.Gameplay : Mode.Menu;
        }

        IEnumerator Start()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            shaderHolders = Resources.LoadAll<Material>("ShaderHolders");
            foreach (Camera c in FindObjectsOfType<Camera>()) Destroy(c.gameObject);
            foreach (Light l in FindObjectsOfType<Light>()) Destroy(l.gameObject);
            AudioManager.Ensure();
            if (mode == Mode.Menu) BuildMenu();
            else yield return BuildGameplay();
        }

        // ------------------------------------------------------------ shared world
        static Camera CreateCamera()
        {
            GameObject go = new GameObject("Main Camera");
            go.tag = "MainCamera";
            Camera cam = go.AddComponent<Camera>();
            cam.fieldOfView = 62f; cam.nearClipPlane = 0.3f; cam.farClipPlane = 220f; cam.allowHDR = false;
            go.AddComponent<AudioListener>();
            return cam;
        }

        static void SetupWorld(Camera cam)
        {
            Color fog = new Color(0.62f, 0.78f, 0.66f);
            GameObject lg = new GameObject("Sun");
            Light sun = lg.AddComponent<Light>();
            sun.type = LightType.Directional; sun.color = new Color(1f, 0.94f, 0.75f); sun.intensity = 1.25f;
            sun.shadows = LightShadows.Soft; sun.shadowStrength = 0.75f;
            lg.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            RenderSettings.sun = sun;

            Material sky = null;
            Material holder = Resources.Load<Material>("ShaderHolders/Sky");
            if (holder != null) sky = new Material(holder);
            else { Shader s = Shader.Find("Skybox/Procedural"); if (s != null) sky = new Material(s); }
            if (sky != null)
            {
                if (sky.HasProperty("_SkyTint")) sky.SetColor("_SkyTint", new Color(0.5f, 0.78f, 0.62f));
                if (sky.HasProperty("_GroundColor")) sky.SetColor("_GroundColor", new Color(0.3f, 0.45f, 0.3f));
                if (sky.HasProperty("_AtmosphereThickness")) sky.SetFloat("_AtmosphereThickness", 1.2f);
                if (sky.HasProperty("_Exposure")) sky.SetFloat("_Exposure", 1.1f);
                RenderSettings.skybox = sky;
                cam.clearFlags = CameraClearFlags.Skybox;
            }
            else { cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = fog; }

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.5f, 0.62f, 0.5f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = 0.011f;
            RenderSettings.fogColor = fog;
            QualitySettings.shadowDistance = 45f;
            QualitySettings.shadowCascades = 2;
        }

        // ------------------------------------------------------------ main menu
        void BuildMenu()
        {
            Time.timeScale = 1f;
            Camera cam = CreateCamera();
            SetupWorld(cam);
            Atmosphere.Attach(cam);
            int[] kinds = { 0, 3, 2, 0 };
            for (int i = 0; i < kinds.Length; i++)
            {
                GameObject seg = EnvironmentSpawner.BuildSegment(kinds[i], 1000 + i * 7919 + 3);
                seg.transform.position = new Vector3(0, 0, -20f + i * TrackGenerator.SegmentLength);
            }
            GameObject pl = new GameObject("MenuPlayer");
            PlayerAnimation anim = PlayerFactory.BuildModel(pl.transform);
            anim.useGameSpeed = false; anim.State = PlayerState.Run;
            cam.transform.position = new Vector3(2.6f, 2.1f, -4.6f);
            cam.transform.rotation = Quaternion.LookRotation(new Vector3(-0.6f, 1.3f, 2f) - cam.transform.position);
            Effects fx = new GameObject("Effects").AddComponent<Effects>();
            new GameObject("MainMenuUI").AddComponent<MainMenuUI>().Build();
        }

        // ------------------------------------------------------------ gameplay
        IEnumerator BuildGameplay()
        {
            Camera cam = CreateCamera();
            SetupWorld(cam);
            Atmosphere.Attach(cam);

            // loading overlay
            Canvas lc = UIBuilder.CreateCanvas("LoadingCanvas", 50);
            Image bg = UIBuilder.Box(lc.transform, "BG", new Color(0.05f, 0.2f, 0.08f, 1f), false);
            UIBuilder.Stretch(bg.rectTransform);
            Text lt = UIBuilder.Label(lc.transform, "LOADING JUNGLE...", 70, UIBuilder.Gold);
            UIBuilder.Anchor(lt.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1000, 120));
            yield return null;

            GameObject mgr = new GameObject("Managers");
            ObjectPool pool = new GameObject("Pool").AddComponent<ObjectPool>();
            new GameObject("Effects").AddComponent<Effects>();
            GameManager gm = mgr.AddComponent<GameManager>();
            mgr.AddComponent<ScoreManager>();
            mgr.AddComponent<CoinManager>();
            mgr.AddComponent<PowerUpManager>();
            mgr.AddComponent<GameOverManager>();

            PlayerController player = PlayerFactory.Create();
            CameraFollow follow = cam.gameObject.AddComponent<CameraFollow>();
            follow.Init(player.transform);
            gm.Player = player; gm.Cam = follow;

            ObstacleSpawner spawner = new GameObject("ObstacleSpawner").AddComponent<ObstacleSpawner>();
            spawner.Init(pool);
            TrackGenerator track = new GameObject("Track").AddComponent<TrackGenerator>();
            track.Init(player.transform, spawner, pool);
            gm.Track = track;

            UIBuilder.EnsureEventSystem();
            new GameObject("GameplayUI").AddComponent<GameplayUI>().Build();
            new GameObject("PauseMenuUI").AddComponent<PauseMenuUI>().Build();
            new GameObject("GameOverUI").AddComponent<GameOverUI>().Build();

            yield return track.Build(p => { lt.text = "LOADING JUNGLE... " + Mathf.RoundToInt(p * 100f) + "%"; });
            Destroy(lc.gameObject);
            gm.StartRun();
            if (AudioManager.Instance != null) AudioManager.Instance.StartAmbience();
        }
    }
}
