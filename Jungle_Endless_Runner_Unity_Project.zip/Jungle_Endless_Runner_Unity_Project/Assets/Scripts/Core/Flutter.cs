using UnityEngine;

namespace JungleRunner
{
    /// <summary>Butterflies and birds: orbit a point and flap two wing pivots.</summary>
    public class Flutter : MonoBehaviour
    {
        public Transform wingL, wingR;
        public Vector3 center;
        public float radius = 1.5f, speed = 1f, bobHeight = 0.4f, flapSpeed = 18f, flapAngle = 50f;
        float phase;
        void Start() { phase = Random.value * 10f; }
        void Update()
        {
            float t = Time.time * speed + phase;
            transform.localPosition = center + new Vector3(Mathf.Cos(t) * radius, Mathf.Sin(t * 1.7f) * bobHeight, Mathf.Sin(t) * radius);
            Vector3 tangent = new Vector3(-Mathf.Sin(t), 0f, Mathf.Cos(t));
            transform.localRotation = Quaternion.LookRotation(tangent);
            float f = Mathf.Sin(Time.time * flapSpeed + phase) * flapAngle;
            if (wingL != null) wingL.localRotation = Quaternion.Euler(0f, 0f, f);
            if (wingR != null) wingR.localRotation = Quaternion.Euler(0f, 0f, -f);
        }
    }
}
