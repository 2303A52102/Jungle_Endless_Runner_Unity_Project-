using UnityEngine;

namespace JungleRunner
{
    /// <summary>Spins and bobs a pickup visual.</summary>
    public class Spinner : MonoBehaviour
    {
        public float degreesPerSecond = 120f, bobAmplitude = 0.2f, bobSpeed = 3f;
        float baseY;
        void Awake() { baseY = transform.localPosition.y; }
        void Update()
        {
            transform.Rotate(0f, degreesPerSecond * Time.deltaTime, 0f, Space.Self);
            Vector3 p = transform.localPosition;
            p.y = baseY + Mathf.Sin(Time.time * bobSpeed) * bobAmplitude;
            transform.localPosition = p;
        }
    }
}
