using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    /// <summary>Jungle colour palette (green / brown / gold). Names starting with "Glow" are emissive.</summary>
    public static class Pal
    {
        static Color C(int r, int g, int b) { return new Color(r / 255f, g / 255f, b / 255f); }
        static readonly Dictionary<string, Color> colors = new Dictionary<string, Color>
        {
            {"Dirt",C(122,86,48)},{"DirtDark",C(88,60,34)},{"Grass",C(60,140,48)},{"GrassLight",C(100,174,56)},{"Forest",C(30,84,34)},
            {"Trunk",C(82,54,29)},{"TrunkLight",C(115,78,42)},{"Leaf1",C(26,115,38)},{"Leaf2",C(46,153,51)},{"Leaf3",C(80,184,52)},{"LeafDark",C(15,76,26)},
            {"Rock",C(115,115,107)},{"RockDark",C(76,76,76)},{"Moss",C(64,115,38)},{"Stone",C(140,133,107)},{"StoneDark",C(98,94,78)},
            {"Wood",C(153,102,51)},{"WoodDark",C(102,66,33)},{"Thatch",C(191,153,64)},{"Door",C(40,26,16)},
            {"Red",C(214,40,36)},{"Yellow",C(250,210,40)},{"Purple",C(150,70,190)},{"Pink",C(240,110,170)},{"Orange",C(245,140,30)},{"White",C(240,240,230)},
            {"Skin",C(232,180,130)},{"Shirt",C(194,166,102)},{"Pants",C(62,76,115)},{"Hat",C(120,78,38)},{"Black",C(30,30,30)},
            {"Monkey",C(110,70,40)},{"MonkeyFace",C(220,180,140)},{"Thorn",C(130,45,45)},{"Rope",C(170,140,90)},
            {"GlowGold",C(255,200,40)},{"GlowCyan",C(60,230,255)},{"GlowOrange",C(255,130,30)},{"GlowRed",C(255,60,60)},
            {"GlowGreen",C(90,255,120)},{"GlowPurple",C(190,90,255)},{"GlowBlue",C(80,120,255)}
        };

        public static Material M(string n)
        {
            Color c;
            if (!colors.TryGetValue(n, out c)) c = Color.magenta;
            bool glow = n.StartsWith("Glow");
            return Mats.Get(n, c, glow ? 0.6f : 0.1f, glow ? 0.3f : 0f, glow ? 0.9f : 0f);
        }
    }
}
