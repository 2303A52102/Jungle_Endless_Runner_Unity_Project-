using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    public class PoolTag : MonoBehaviour
    {
        public string key;
        public Object owner;   // TrackSegment currently owning this object (prevents stale releases)
    }

    /// <summary>Keyed GameObject pool. Obstacles, coins and power-ups are never destroyed during a run.</summary>
    public class ObjectPool : MonoBehaviour
    {
        public static ObjectPool Instance { get; private set; }
        readonly Dictionary<string, Stack<GameObject>> free = new Dictionary<string, Stack<GameObject>>();
        readonly Dictionary<string, System.Func<GameObject>> makers = new Dictionary<string, System.Func<GameObject>>();

        void Awake() { Instance = this; }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Register(string key, System.Func<GameObject> maker)
        {
            makers[key] = maker;
            if (!free.ContainsKey(key)) free[key] = new Stack<GameObject>();
        }

        public GameObject Get(string key, Vector3 pos, Quaternion rot)
        {
            GameObject go = null;
            Stack<GameObject> s = free[key];
            while (s.Count > 0 && go == null) go = s.Pop();
            if (go == null)
            {
                go = makers[key]();
                PoolTag tag = go.AddComponent<PoolTag>();
                tag.key = key;
                go.SetActive(false);
            }
            go.transform.SetParent(transform, false);
            go.transform.SetPositionAndRotation(pos, rot);
            go.SetActive(true);
            return go;
        }

        public void Release(GameObject go)
        {
            if (go == null || !go.activeSelf) return;
            PoolTag tag = go.GetComponent<PoolTag>();
            if (tag == null) { Destroy(go); return; }
            tag.owner = null;
            go.SetActive(false);
            go.transform.SetParent(transform, false);
            free[tag.key].Push(go);
        }

        public void Prewarm(string key, int count)
        {
            GameObject[] tmp = new GameObject[count];
            for (int i = 0; i < count; i++) tmp[i] = Get(key, Vector3.zero, Quaternion.identity);
            for (int i = 0; i < count; i++) Release(tmp[i]);
        }
    }
}
