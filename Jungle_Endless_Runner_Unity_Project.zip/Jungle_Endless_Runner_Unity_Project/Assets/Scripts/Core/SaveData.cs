using UnityEngine;

namespace JungleRunner
{
    /// <summary>PlayerPrefs wrapper: best score, coin balance, audio settings.</summary>
    public static class SaveData
    {
        const string BestKey = "JER_BestScore", CoinsKey = "JER_TotalCoins", SoundKey = "JER_Sound", MusicKey = "JER_Music";
        public static int BestScore { get { return PlayerPrefs.GetInt(BestKey, 0); } set { PlayerPrefs.SetInt(BestKey, value); } }
        public static int TotalCoins { get { return PlayerPrefs.GetInt(CoinsKey, 0); } set { PlayerPrefs.SetInt(CoinsKey, Mathf.Max(0, value)); } }
        public static bool SoundOn { get { return PlayerPrefs.GetInt(SoundKey, 1) == 1; } set { PlayerPrefs.SetInt(SoundKey, value ? 1 : 0); } }
        public static bool MusicOn { get { return PlayerPrefs.GetInt(MusicKey, 1) == 1; } set { PlayerPrefs.SetInt(MusicKey, value ? 1 : 0); } }
        public static void Save() { PlayerPrefs.Save(); }
        public static void ResetProgress() { PlayerPrefs.DeleteKey(BestKey); PlayerPrefs.DeleteKey(CoinsKey); PlayerPrefs.Save(); }
    }
}
