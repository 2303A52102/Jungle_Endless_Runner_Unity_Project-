using UnityEngine;

namespace JungleRunner
{
    /// <summary>Helpers for building objects out of Unity primitives (colliders stripped by default).</summary>
    public static class Prim
    {
        public static GameObject Make(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material mat, bool castShadow = false)
        {
            return Make(type, parent, pos, scale, mat, Vector3.zero, castShadow);
        }

        public static GameObject Make(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Material mat, Vector3 euler, bool castShadow = false)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            Collider c = go.GetComponent<Collider>();
            if (c != null) Object.DestroyImmediate(c);
            Transform t = go.transform;
            t.SetParent(parent, false);
            t.localPosition = pos; t.localRotation = Quaternion.Euler(euler); t.localScale = scale;
            Renderer r = go.GetComponent<Renderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = castShadow ? UnityEngine.Rendering.ShadowCastingMode.On : UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = true;
            return go;
        }

        public static Transform Empty(Transform parent, string name, Vector3 pos)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            return go.transform;
        }
    }
}
