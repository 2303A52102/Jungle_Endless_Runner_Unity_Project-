using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    /// <summary>Merges all static decor under a root into one mesh per material (big draw-call saving on mobile).</summary>
    public static class MeshCombiner
    {
        public static void Combine(GameObject root)
        {
            MeshFilter[] filters = root.GetComponentsInChildren<MeshFilter>(false);
            Dictionary<Material, List<CombineInstance>> groups = new Dictionary<Material, List<CombineInstance>>();
            Matrix4x4 inv = root.transform.worldToLocalMatrix;
            List<GameObject> toDestroy = new List<GameObject>();
            foreach (MeshFilter f in filters)
            {
                MeshRenderer r = f.GetComponent<MeshRenderer>();
                if (r == null || f.sharedMesh == null || r.sharedMaterial == null) continue;
                List<CombineInstance> list;
                if (!groups.TryGetValue(r.sharedMaterial, out list)) { list = new List<CombineInstance>(); groups[r.sharedMaterial] = list; }
                CombineInstance ci = new CombineInstance();
                ci.mesh = f.sharedMesh;
                ci.transform = inv * f.transform.localToWorldMatrix;
                list.Add(ci);
                toDestroy.Add(f.gameObject);
            }
            foreach (GameObject g in toDestroy) Object.Destroy(g);
            foreach (KeyValuePair<Material, List<CombineInstance>> kv in groups)
            {
                Mesh mesh = new Mesh();
                mesh.name = "Combined_" + kv.Key.name;
                mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.CombineMeshes(kv.Value.ToArray(), true, true);
                GameObject go = new GameObject("Combined_" + kv.Key.name);
                go.transform.SetParent(root.transform, false);
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                MeshRenderer mr = go.AddComponent<MeshRenderer>();
                mr.sharedMaterial = kv.Key;
                mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                mr.receiveShadows = true;
            }
        }
    }
}
