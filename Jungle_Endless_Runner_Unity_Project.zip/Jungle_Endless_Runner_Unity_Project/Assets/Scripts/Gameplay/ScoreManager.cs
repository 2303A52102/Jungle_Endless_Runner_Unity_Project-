using UnityEngine;

namespace JungleRunner
{
    public class ScoreManager : MonoBehaviour
    {
        public static ScoreManager Instance { get; private set; }
        float score;
        public int Score { get { return (int)score; } }
        public int BestScore { get; private set; }
        public int Multiplier
        {
            get { return (PowerUpManager.Instance != null && PowerUpManager.Instance.IsActive(PowerUpType.ScoreMultiplier)) ? 2 : 1; }
        }

        void Awake() { Instance = this; BestScore = SaveData.BestScore; }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public void AddDistance(float meters) { score += meters * Multiplier; }
        public void AddBonus(int points) { score += points * Multiplier; }

        /// <summary>Saves the high score if beaten. Returns true when a new best was set.</summary>
        public bool CommitHighScore()
        {
            if (Score > BestScore) { BestScore = Score; SaveData.BestScore = BestScore; SaveData.Save(); return true; }
            return false;
        }
    }
}
