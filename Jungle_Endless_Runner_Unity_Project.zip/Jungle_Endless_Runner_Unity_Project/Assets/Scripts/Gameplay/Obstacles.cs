using UnityEngine;

namespace JungleRunner
{
    public enum ObstacleType { Crate, FallenLog, StoneBarrier, JungleRock, ThornyBush, BrokenBridge, TreeRoots, JungleCart }
    /// <summary>Low = jump over, High = slide under, Block = change lane.</summary>
    public enum ObstacleKind { Low, High, Block }

    public class Obstacle : MonoBehaviour
    {
        public ObstacleType type;
        public ObstacleKind kind;
    }

    public static class ObstacleFactory
    {
        static Vector3 V(float x, float y, float z) { return new Vector3(x, y, z); }

        public static GameObject Build(ObstacleType t)
        {
            GameObject root = new GameObject("Obstacle_" + t);
            Obstacle ob = root.AddComponent<Obstacle>(); ob.type = t;
            BoxCollider box = root.AddComponent<BoxCollider>(); box.isTrigger = true;
            Transform tr = root.transform;
            PrimitiveType cube = PrimitiveType.Cube, sph = PrimitiveType.Sphere, cyl = PrimitiveType.Cylinder, cap = PrimitiveType.Capsule;
            switch (t)
            {
                case ObstacleType.Crate:
                    ob.kind = ObstacleKind.Low;
                    Prim.Make(cube, tr, V(0, 0.55f, 0), V(1.3f, 1.1f, 1.3f), Pal.M("Wood"), true);
                    for (int sx = -1; sx <= 1; sx += 2)
                        for (int sz = -1; sz <= 1; sz += 2)
                            Prim.Make(cube, tr, V(sx * 0.62f, 0.56f, sz * 0.62f), V(0.16f, 1.12f, 0.16f), Pal.M("WoodDark"), true);
                    Prim.Make(cube, tr, V(0, 0.2f, 0), V(1.36f, 0.14f, 1.36f), Pal.M("WoodDark"), true);
                    Prim.Make(cube, tr, V(0, 0.92f, 0), V(1.36f, 0.14f, 1.36f), Pal.M("WoodDark"), true);
                    box.center = V(0, 0.55f, 0); box.size = V(1.4f, 1.1f, 1.4f);
                    break;
                case ObstacleType.FallenLog:
                    ob.kind = ObstacleKind.Low;
                    Prim.Make(cyl, tr, V(0, 0.45f, 0), V(0.9f, 1.15f, 0.9f), Pal.M("Trunk"), V(0, 0, 90), true);
                    Prim.Make(sph, tr, V(-0.3f, 0.92f, 0), V(0.7f, 0.2f, 0.6f), Pal.M("Moss"), true);
                    Prim.Make(cap, tr, V(0.5f, 0.85f, 0.2f), V(0.12f, 0.25f, 0.12f), Pal.M("TrunkLight"), V(0, 0, -35), true);
                    box.center = V(0, 0.45f, 0); box.size = V(2.3f, 0.95f, 1.0f);
                    break;
                case ObstacleType.StoneBarrier:
                    ob.kind = ObstacleKind.High;
                    Prim.Make(cube, tr, V(-1.05f, 1.2f, 0), V(0.5f, 2.4f, 0.8f), Pal.M("Stone"), true);
                    Prim.Make(cube, tr, V(1.05f, 1.2f, 0), V(0.5f, 2.4f, 0.8f), Pal.M("Stone"), true);
                    Prim.Make(cube, tr, V(0, 1.75f, 0), V(2.6f, 1.3f, 1.0f), Pal.M("StoneDark"), true);
                    Prim.Make(sph, tr, V(-0.4f, 2.4f, 0), V(0.9f, 0.25f, 0.8f), Pal.M("Moss"), true);
                    Prim.Make(cube, tr, V(0, 1.75f, -0.51f), V(1.2f, 0.25f, 0.04f), Pal.M("GlowGold"));
                    box.center = V(0, 1.75f, 0); box.size = V(2.4f, 1.3f, 1.3f);
                    break;
                case ObstacleType.JungleRock:
                    ob.kind = ObstacleKind.Block;
                    Prim.Make(sph, tr, V(0, 1.0f, 0), V(2.1f, 2.3f, 1.9f), Pal.M("Rock"), true);
                    Prim.Make(sph, tr, V(0.7f, 0.5f, -0.5f), V(1.1f, 1.0f, 1.0f), Pal.M("RockDark"), true);
                    Prim.Make(sph, tr, V(-0.1f, 2.0f, 0), V(1.4f, 0.4f, 1.2f), Pal.M("Moss"), true);
                    box.center = V(0, 1.1f, 0); box.size = V(2.0f, 2.2f, 1.8f);
                    break;
                case ObstacleType.ThornyBush:
                    ob.kind = ObstacleKind.Low;
                    Prim.Make(sph, tr, V(0, 0.5f, 0), V(1.7f, 1.0f, 1.4f), Pal.M("LeafDark"), true);
                    Prim.Make(sph, tr, V(0.4f, 0.65f, 0.1f), V(1.0f, 0.8f, 1.0f), Pal.M("Leaf1"), true);
                    for (int i = 0; i < 8; i++)
                    {
                        float a = i * 45f * Mathf.Deg2Rad;
                        Prim.Make(cap, tr, V(Mathf.Cos(a) * 0.7f, 0.6f + (i % 2) * 0.2f, Mathf.Sin(a) * 0.55f), V(0.06f, 0.2f, 0.06f), Pal.M("Thorn"),
                            V(Mathf.Sin(a) * 60f, 0, -Mathf.Cos(a) * 60f), true);
                    }
                    box.center = V(0, 0.5f, 0); box.size = V(1.6f, 1.0f, 1.3f);
                    break;
                case ObstacleType.BrokenBridge:
                    ob.kind = ObstacleKind.Low;
                    Prim.Make(cube, tr, V(-0.95f, 0.5f, 0), V(0.25f, 1.0f, 0.25f), Pal.M("WoodDark"), V(0, 0, 6), true);
                    Prim.Make(cube, tr, V(0.95f, 0.45f, 0), V(0.25f, 0.9f, 0.25f), Pal.M("WoodDark"), V(0, 0, -8), true);
                    Prim.Make(cube, tr, V(0, 0.8f, 0), V(2.3f, 0.2f, 0.2f), Pal.M("Wood"), V(0, 0, 14), true);
                    Prim.Make(cube, tr, V(0.1f, 0.12f, 0.3f), V(1.8f, 0.1f, 0.4f), Pal.M("Wood"), V(0, 12, 0), true);
                    Prim.Make(cube, tr, V(-0.2f, 0.2f, -0.3f), V(1.5f, 0.1f, 0.4f), Pal.M("WoodDark"), V(0, -18, 8), true);
                    Prim.Make(cyl, tr, V(0.9f, 0.9f, 0), V(0.03f, 0.5f, 0.03f), Pal.M("Rope"), V(0, 0, 25), true);
                    box.center = V(0, 0.5f, 0); box.size = V(2.3f, 1.0f, 0.9f);
                    break;
                case ObstacleType.TreeRoots:
                    ob.kind = ObstacleKind.High;
                    Prim.Make(cyl, tr, V(0, 1.65f, 0), V(0.95f, 1.2f, 0.95f), Pal.M("Trunk"), V(0, 0, 90), true);
                    Prim.Make(cap, tr, V(-1.1f, 0.8f, 0), V(0.5f, 0.95f, 0.5f), Pal.M("TrunkLight"), V(0, 0, 18), true);
                    Prim.Make(cap, tr, V(1.1f, 0.8f, 0), V(0.5f, 0.95f, 0.5f), Pal.M("TrunkLight"), V(0, 0, -18), true);
                    Prim.Make(sph, tr, V(0, 2.2f, 0), V(1.6f, 0.3f, 0.9f), Pal.M("Moss"), true);
                    box.center = V(0, 1.65f, 0); box.size = V(2.4f, 1.0f, 1.0f);
                    break;
                default: // JungleCart
                    ob.kind = ObstacleKind.Block;
                    Prim.Make(cube, tr, V(0, 0.95f, 0), V(1.7f, 0.8f, 1.5f), Pal.M("Wood"), true);
                    Prim.Make(cube, tr, V(0, 1.4f, 0.74f), V(1.7f, 0.5f, 0.1f), Pal.M("WoodDark"), true);
                    Prim.Make(cube, tr, V(0, 1.4f, -0.74f), V(1.7f, 0.5f, 0.1f), Pal.M("WoodDark"), true);
                    Prim.Make(cyl, tr, V(-0.95f, 0.45f, 0), V(0.9f, 0.1f, 0.9f), Pal.M("TrunkLight"), V(0, 0, 90), true);
                    Prim.Make(cyl, tr, V(0.95f, 0.45f, 0), V(0.9f, 0.1f, 0.9f), Pal.M("TrunkLight"), V(0, 0, 90), true);
                    Prim.Make(cube, tr, V(0.3f, 1.65f, 0), V(0.7f, 0.5f, 0.7f), Pal.M("WoodDark"), true);
                    Prim.Make(cube, tr, V(0, 1.7f, 1.2f), V(0.1f, 0.1f, 1.4f), Pal.M("Trunk"), V(-20, 0, 0), true);
                    Prim.Make(cube, tr, V(0, 1.2f, -0.2f), V(0.1f, 1.8f, 0.1f), Pal.M("Trunk"), true);
                    box.center = V(0, 0.95f, 0); box.size = V(2.0f, 1.9f, 1.8f);
                    break;
            }
            return root;
        }
    }
}
