using UnityEngine;

namespace JungleRunner
{
    public enum PowerUpType { Magnet, Shield, SpeedBoost, ScoreMultiplier, CoinBonus }

    /// <summary>Tracks the five power-ups. Magnet 10s, Shield (one hit, max 20s), Speed Boost 6s (invincible), Score x2 12s, Coin Bonus +25 coins.</summary>
    public class PowerUpManager : MonoBehaviour
    {
        public static PowerUpManager Instance { get; private set; }
        public static readonly string[] Names = { "MAGNET", "SHIELD", "SPEED BOOST", "SCORE x2", "COIN BONUS" };
        public static readonly Color[] Colors =
        {
            new Color(1f, 0.3f, 0.3f), new Color(0.3f, 0.9f, 1f), new Color(1f, 0.6f, 0.15f), new Color(1f, 0.85f, 0.2f), new Color(0.4f, 1f, 0.5f)
        };
        public const int BonusCoins = 25;
        readonly float[] remaining = new float[5];

        public bool MagnetActive { get { return remaining[(int)PowerUpType.Magnet] > 0f; } }
        public bool SpeedBoostActive { get { return remaining[(int)PowerUpType.SpeedBoost] > 0f; } }
        public bool IsActive(PowerUpType t) { return remaining[(int)t] > 0f; }
        public float Remaining(PowerUpType t) { return remaining[(int)t]; }

        public static float Duration(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.Magnet: return 10f;
                case PowerUpType.Shield: return 20f;
                case PowerUpType.SpeedBoost: return 6f;
                case PowerUpType.ScoreMultiplier: return 12f;
                default: return 0f;
            }
        }

        void Awake() { Instance = this; enabled = false; }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Activate(PowerUpType t, Vector3 at)
        {
            AudioManager.Play(t == PowerUpType.Shield ? Sfx.Shield : Sfx.PowerUp);
            Effects.Burst(at, Colors[(int)t], 24);
            if (t == PowerUpType.CoinBonus)
            {
                if (CoinManager.Instance != null) CoinManager.Instance.AddBonusCoins(BonusCoins);
                return;
            }
            remaining[(int)t] = Duration(t);
            enabled = true;
        }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || !gm.IsPlaying) return;
            bool any = false;
            float dt = Time.deltaTime;
            for (int i = 0; i < remaining.Length; i++)
            {
                if (remaining[i] <= 0f) continue;
                remaining[i] = Mathf.Max(0f, remaining[i] - dt);
                if (remaining[i] > 0f) any = true;
            }
            if (!any) enabled = false;
        }

        public bool ConsumeShield()
        {
            if (remaining[(int)PowerUpType.Shield] > 0f) { remaining[(int)PowerUpType.Shield] = 0f; return true; }
            return false;
        }
    }
}
