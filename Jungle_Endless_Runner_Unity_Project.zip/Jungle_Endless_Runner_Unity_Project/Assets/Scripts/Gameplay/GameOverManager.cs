using System.Collections;
using UnityEngine;

namespace JungleRunner
{
    public class GameOverManager : MonoBehaviour
    {
        public static GameOverManager Instance { get; private set; }
        public const int ReviveCost = 50;
        public bool IsNewBest { get; private set; }
        public event System.Action OnShowScreen;

        public bool CanRevive
        {
            get { return GameManager.Instance != null && GameManager.Instance.RevivesUsed == 0 && SaveData.TotalCoins >= ReviveCost; }
        }

        void Awake() { Instance = this; }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Begin()
        {
            IsNewBest = ScoreManager.Instance.CommitHighScore();
            SaveData.Save();
            StartCoroutine(Sequence());
        }

        IEnumerator Sequence()
        {
            yield return new WaitForSecondsRealtime(1.1f);
            if (OnShowScreen != null) OnShowScreen();
        }

        public bool TryRevive()
        {
            if (!CanRevive) return false;
            SaveData.TotalCoins = SaveData.TotalCoins - ReviveCost;
            SaveData.Save();
            GameManager.Instance.Revive();
            return true;
        }
    }
}
