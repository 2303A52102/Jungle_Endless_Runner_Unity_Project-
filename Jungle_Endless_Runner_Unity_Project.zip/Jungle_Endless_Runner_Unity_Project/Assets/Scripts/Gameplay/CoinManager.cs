using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    public class CoinManager : MonoBehaviour
    {
        public static CoinManager Instance { get; private set; }
        public int RunCoins { get; private set; }
        public int TotalCoins { get { return SaveData.TotalCoins; } }
        readonly List<Coin> active = new List<Coin>();

        void Awake() { Instance = this; }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Register(Coin c) { if (!active.Contains(c)) active.Add(c); }
        public void Unregister(Coin c) { active.Remove(c); }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || active.Count == 0) return;
            Quaternion spin = Quaternion.Euler(0f, Time.time * 220f, 0f);
            bool magnet = gm.IsPlaying && PowerUpManager.Instance != null && PowerUpManager.Instance.MagnetActive && gm.Player != null;
            Vector3 target = magnet ? gm.Player.transform.position + Vector3.up : Vector3.zero;
            float dt = Time.deltaTime;
            for (int i = 0; i < active.Count; i++)
            {
                Coin c = active[i];
                if (c.visual != null) c.visual.localRotation = spin;
                if (magnet)
                {
                    Vector3 p = c.transform.position;
                    if ((target - p).sqrMagnitude < 100f) c.transform.position = Vector3.MoveTowards(p, target, 30f * dt);
                }
            }
        }

        public void Collect(Coin c)
        {
            RunCoins++;
            SaveData.TotalCoins = SaveData.TotalCoins + 1;
            if (ScoreManager.Instance != null) ScoreManager.Instance.AddBonus(10);
            Effects.Burst(c.transform.position, new Color(1f, 0.85f, 0.2f), 10);
            AudioManager.Play(Sfx.Coin, 0.6f);
            if (ObjectPool.Instance != null) ObjectPool.Instance.Release(c.gameObject);
        }

        public void AddBonusCoins(int n)
        {
            RunCoins += n;
            SaveData.TotalCoins = SaveData.TotalCoins + n;
        }
    }
}
