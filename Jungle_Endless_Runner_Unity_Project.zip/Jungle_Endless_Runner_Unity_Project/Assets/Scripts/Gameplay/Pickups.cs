using UnityEngine;

namespace JungleRunner
{
    public class Coin : MonoBehaviour
    {
        public Transform visual;
        void OnEnable() { if (CoinManager.Instance != null) CoinManager.Instance.Register(this); }
        void OnDisable() { if (CoinManager.Instance != null) CoinManager.Instance.Unregister(this); }
    }

    public class PowerUpPickup : MonoBehaviour
    {
        public PowerUpType type;
    }

    public static class CoinFactory
    {
        public static GameObject Build()
        {
            GameObject root = new GameObject("Coin");
            Coin coin = root.AddComponent<Coin>();
            SphereCollider sc = root.AddComponent<SphereCollider>();
            sc.isTrigger = true; sc.radius = 0.6f;
            Transform vis = Prim.Empty(root.transform, "Visual", Vector3.zero);
            coin.visual = vis;
            Prim.Make(PrimitiveType.Cylinder, vis, Vector3.zero, new Vector3(0.62f, 0.05f, 0.62f), Pal.M("GlowGold"), new Vector3(90f, 0f, 0f));
            Prim.Make(PrimitiveType.Cylinder, vis, Vector3.zero, new Vector3(0.45f, 0.07f, 0.45f), Pal.M("Yellow"), new Vector3(90f, 0f, 0f));
            return root;
        }
    }

    public static class PowerUpFactory
    {
        public static GameObject Build(PowerUpType t)
        {
            GameObject root = new GameObject("PowerUp_" + t);
            PowerUpPickup pu = root.AddComponent<PowerUpPickup>(); pu.type = t;
            SphereCollider sc = root.AddComponent<SphereCollider>();
            sc.isTrigger = true; sc.radius = 1.0f; sc.center = new Vector3(0f, 1.1f, 0f);
            Transform vis = Prim.Empty(root.transform, "Visual", new Vector3(0f, 1.1f, 0f));
            Spinner sp = vis.gameObject.AddComponent<Spinner>(); sp.degreesPerSecond = 110f; sp.bobAmplitude = 0.18f;
            PrimitiveType cube = PrimitiveType.Cube, sph = PrimitiveType.Sphere, cyl = PrimitiveType.Cylinder;
            Vector3 z = Vector3.zero;
            switch (t)
            {
                case PowerUpType.Magnet: // horseshoe magnet
                    Prim.Make(cube, vis, new Vector3(-0.3f, -0.05f, 0f), new Vector3(0.22f, 0.7f, 0.22f), Pal.M("GlowRed"), true);
                    Prim.Make(cube, vis, new Vector3(0.3f, -0.05f, 0f), new Vector3(0.22f, 0.7f, 0.22f), Pal.M("GlowRed"), true);
                    Prim.Make(cube, vis, new Vector3(0f, 0.32f, 0f), new Vector3(0.82f, 0.22f, 0.22f), Pal.M("GlowRed"), true);
                    Prim.Make(cube, vis, new Vector3(-0.3f, -0.42f, 0f), new Vector3(0.24f, 0.14f, 0.24f), Pal.M("White"), true);
                    Prim.Make(cube, vis, new Vector3(0.3f, -0.42f, 0f), new Vector3(0.24f, 0.14f, 0.24f), Pal.M("White"), true);
                    break;
                case PowerUpType.Shield: // glowing jungle crystal
                    Prim.Make(cube, vis, z, new Vector3(0.55f, 0.55f, 0.55f), Pal.M("GlowCyan"), new Vector3(45f, 0f, 45f), true);
                    Prim.Make(sph, vis, z, new Vector3(1.0f, 1.0f, 1.0f), Mats.Fade("ShieldOrb", new Color(0.3f, 0.9f, 1f, 0.22f)));
                    break;
                case PowerUpType.SpeedBoost: // magical fruit
                    Prim.Make(sph, vis, z, new Vector3(0.6f, 0.6f, 0.6f), Pal.M("GlowOrange"), true);
                    Prim.Make(sph, vis, new Vector3(0.08f, 0.34f, 0f), new Vector3(0.32f, 0.07f, 0.16f), Pal.M("Leaf3"), new Vector3(0f, 0f, 25f), true);
                    Prim.Make(cyl, vis, new Vector3(0f, 0.32f, 0f), new Vector3(0.05f, 0.08f, 0.05f), Pal.M("Trunk"), true);
                    break;
                case PowerUpType.ScoreMultiplier: // golden idol
                    Prim.Make(cyl, vis, new Vector3(0f, -0.35f, 0f), new Vector3(0.5f, 0.1f, 0.5f), Pal.M("GlowGold"), true);
                    Prim.Make(PrimitiveType.Capsule, vis, new Vector3(0f, -0.02f, 0f), new Vector3(0.38f, 0.3f, 0.3f), Pal.M("GlowGold"), true);
                    Prim.Make(sph, vis, new Vector3(0f, 0.38f, 0f), new Vector3(0.34f, 0.34f, 0.34f), Pal.M("GlowGold"), true);
                    Prim.Make(sph, vis, new Vector3(0.09f, 0.42f, 0.14f), new Vector3(0.07f, 0.07f, 0.07f), Pal.M("Black"));
                    Prim.Make(sph, vis, new Vector3(-0.09f, 0.42f, 0.14f), new Vector3(0.07f, 0.07f, 0.07f), Pal.M("Black"));
                    break;
                default: // coin bonus: energy orb with coin stack
                    Prim.Make(sph, vis, z, new Vector3(0.7f, 0.7f, 0.7f), Pal.M("GlowGreen"), true);
                    for (int i = 0; i < 3; i++)
                        Prim.Make(cyl, vis, new Vector3(0f, -0.1f + i * 0.16f, 0f), new Vector3(0.42f, 0.04f, 0.42f), Pal.M("GlowGold"), true);
                    break;
            }
            return root;
        }
    }
}
