using UnityEngine;
using UnityEngine.SceneManagement;

namespace JungleRunner
{
    public enum GameState { Loading, Playing, Paused, GameOver }

    /// <summary>Central run state: speed ramp, distance, pause / revive / restart / home.</summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }
        public const float StartSpeed = 14f, MaxSpeed = 34f, Acceleration = 0.14f;

        public GameState State { get; private set; }
        public float BaseSpeed { get; private set; }
        public float Distance { get; private set; }
        public int RevivesUsed { get; private set; }
        public bool IsPlaying { get { return State == GameState.Playing; } }
        public float Speed
        {
            get { return BaseSpeed * ((PowerUpManager.Instance != null && PowerUpManager.Instance.SpeedBoostActive) ? 1.55f : 1f); }
        }
        public float Difficulty01 { get { return Mathf.Clamp01((BaseSpeed - StartSpeed) / (MaxSpeed - StartSpeed)); } }

        public PlayerController Player;
        public TrackGenerator Track;
        public CameraFollow Cam;

        public event System.Action OnRunStarted, OnPaused, OnResumed, OnRunEnded, OnRevived;

        void Awake() { Instance = this; Time.timeScale = 1f; State = GameState.Loading; BaseSpeed = StartSpeed; }
        void OnDestroy() { if (Instance == this) Instance = null; Time.timeScale = 1f; }

        public void StartRun()
        {
            Distance = 0f; BaseSpeed = StartSpeed; RevivesUsed = 0;
            State = GameState.Playing;
            if (OnRunStarted != null) OnRunStarted();
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P)) TogglePause();
            if (State != GameState.Playing) return;
            float dt = Time.deltaTime;
            BaseSpeed = Mathf.Min(MaxSpeed, BaseSpeed + Acceleration * dt);
            float step = Speed * dt;
            Distance += step;
            if (ScoreManager.Instance != null) ScoreManager.Instance.AddDistance(step);
        }

        void OnApplicationPause(bool paused) { if (paused && State == GameState.Playing) Pause(); }

        public void TogglePause()
        {
            if (State == GameState.Playing) Pause();
            else if (State == GameState.Paused) Resume();
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            State = GameState.Paused; Time.timeScale = 0f;
            SaveData.Save();
            if (OnPaused != null) OnPaused();
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            State = GameState.Playing; Time.timeScale = 1f;
            if (OnResumed != null) OnResumed();
        }

        public void EndRun()
        {
            if (State != GameState.Playing) return;
            State = GameState.GameOver;
            AudioManager.Play(Sfx.Hit);
            AudioManager.Play(Sfx.GameOver);
            if (Cam != null) Cam.Shake(0.5f, 0.5f);
            if (OnRunEnded != null) OnRunEnded();
            if (GameOverManager.Instance != null) GameOverManager.Instance.Begin();
        }

        public void Revive()
        {
            RevivesUsed++;
            if (Player != null && Track != null)
                Track.ClearObstacles(Player.transform.position.z - 6f, Player.transform.position.z + 45f);
            if (Player != null) Player.Revive();
            BaseSpeed = Mathf.Max(StartSpeed, BaseSpeed * 0.8f);
            State = GameState.Playing;
            if (OnRevived != null) OnRevived();
        }

        public void Restart() { Time.timeScale = 1f; SaveData.Save(); SceneManager.LoadScene(SceneManager.GetActiveScene().name); }
        public void GoHome() { Time.timeScale = 1f; SaveData.Save(); SceneManager.LoadScene("MainMenu"); }
    }
}
