using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace JungleRunner
{
    public enum Sfx { Click, Coin, Jump, Slide, Hit, PowerUp, Shield, GameOver, Land, Chirp }

    /// <summary>All audio is synthesised at start-up (no audio files needed): SFX + a looping tropical music track.</summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }
        const int SR = 22050;
        AudioSource music, sfx;
        readonly Dictionary<Sfx, AudioClip> clips = new Dictionary<Sfx, AudioClip>();
        public bool SoundOn { get; private set; }
        public bool MusicOn { get; private set; }

        public static void Ensure()
        {
            if (Instance != null) return;
            new GameObject("AudioManager").AddComponent<AudioManager>();
        }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SoundOn = SaveData.SoundOn; MusicOn = SaveData.MusicOn;
            music = gameObject.AddComponent<AudioSource>(); music.loop = true; music.volume = 0.4f; music.playOnAwake = false;
            sfx = gameObject.AddComponent<AudioSource>(); sfx.playOnAwake = false;
            BuildClips();
            music.clip = BuildMusic();
            Apply();
            music.Play();
        }

        public static void Play(Sfx s, float vol = 1f)
        {
            if (Instance == null) return;
            AudioClip c;
            if (Instance.clips.TryGetValue(s, out c)) Instance.sfx.PlayOneShot(c, vol);
        }

        public void SetSound(bool on) { SoundOn = on; SaveData.SoundOn = on; SaveData.Save(); Apply(); }
        public void SetMusic(bool on) { MusicOn = on; SaveData.MusicOn = on; SaveData.Save(); Apply(); }
        void Apply() { sfx.mute = !SoundOn; music.mute = !(SoundOn && MusicOn); }

        public void StartAmbience() { StopAllCoroutines(); StartCoroutine(Ambience()); }
        public void StopAmbience() { StopAllCoroutines(); }
        IEnumerator Ambience()
        {
            while (true)
            {
                yield return new WaitForSeconds(Random.Range(4f, 9f));
                Play(Sfx.Chirp, 0.25f);
            }
        }

        // ---------- synthesis ----------
        static AudioClip Make(string n, float[] d) { AudioClip c = AudioClip.Create(n, d.Length, 1, SR, false); c.SetData(d, 0); return c; }

        static float[] Sweep(float dur, float f0, float f1, float vol)
        {
            int n = (int)(dur * SR); float[] d = new float[n]; float ph = 0f;
            for (int i = 0; i < n; i++)
            {
                float t = i / (float)n;
                ph += 2f * Mathf.PI * Mathf.Lerp(f0, f1, t) / SR;
                float env = (1f - t) * Mathf.Min(1f, i / 80f);
                d[i] = Mathf.Sin(ph) * vol * env;
            }
            return d;
        }

        static float[] Noise(float dur, float vol, float a)
        {
            int n = (int)(dur * SR); float[] d = new float[n]; float y = 0f;
            System.Random r = new System.Random(7);
            for (int i = 0; i < n; i++)
            {
                float x = (float)r.NextDouble() * 2f - 1f;
                y += a * (x - y);
                float t = i / (float)n;
                d[i] = y * vol * (1f - t) * (1f - t);
            }
            return d;
        }

        static float[] Concat(params float[][] parts)
        {
            int len = 0; foreach (float[] p in parts) len += p.Length;
            float[] d = new float[len]; int o = 0;
            foreach (float[] p in parts) { System.Array.Copy(p, 0, d, o, p.Length); o += p.Length; }
            return d;
        }

        static float[] Mix(float[] a, float[] b)
        {
            float[] d = new float[Mathf.Max(a.Length, b.Length)];
            for (int i = 0; i < a.Length; i++) d[i] += a[i];
            for (int i = 0; i < b.Length; i++) d[i] += b[i];
            return d;
        }

        static float[] Silence(float dur) { return new float[(int)(dur * SR)]; }

        void BuildClips()
        {
            clips[Sfx.Click] = Make("click", Sweep(0.06f, 700f, 900f, 0.4f));
            clips[Sfx.Coin] = Make("coin", Concat(Sweep(0.07f, 988f, 988f, 0.4f), Sweep(0.18f, 1319f, 1319f, 0.4f)));
            clips[Sfx.Jump] = Make("jump", Sweep(0.22f, 300f, 700f, 0.4f));
            clips[Sfx.Slide] = Make("slide", Noise(0.25f, 0.5f, 0.25f));
            clips[Sfx.Land] = Make("land", Noise(0.09f, 0.5f, 0.12f));
            clips[Sfx.Hit] = Make("hit", Mix(Noise(0.4f, 0.9f, 0.15f), Sweep(0.4f, 180f, 45f, 0.7f)));
            clips[Sfx.PowerUp] = Make("powerup", Concat(Sweep(0.08f, 523f, 523f, 0.4f), Sweep(0.08f, 659f, 659f, 0.4f), Sweep(0.08f, 784f, 784f, 0.4f), Sweep(0.2f, 1047f, 1047f, 0.4f)));
            clips[Sfx.Shield] = Make("shield", Mix(Sweep(0.3f, 800f, 200f, 0.4f), Noise(0.3f, 0.3f, 0.3f)));
            clips[Sfx.GameOver] = Make("gameover", Concat(Sweep(0.2f, 440f, 440f, 0.4f), Sweep(0.2f, 392f, 392f, 0.4f), Sweep(0.2f, 330f, 330f, 0.4f), Sweep(0.45f, 262f, 220f, 0.4f)));
            clips[Sfx.Chirp] = Make("chirp", Concat(Sweep(0.07f, 2600f, 3600f, 0.3f), Silence(0.04f), Sweep(0.07f, 3300f, 2500f, 0.3f), Silence(0.04f), Sweep(0.1f, 2800f, 3800f, 0.3f)));
        }

        static void Marimba(float[] d, float start, float dur, float f, float amp)
        {
            int s = (int)(start * SR), n = (int)(dur * SR);
            for (int i = 0; i < n; i++)
            {
                int idx = s + i; if (idx >= d.Length) break;
                float t = i / (float)SR;
                float v = Mathf.Sin(2f * Mathf.PI * f * t) + 0.3f * Mathf.Sin(2f * Mathf.PI * f * 4f * t) * Mathf.Exp(-t * 14f);
                d[idx] += v * Mathf.Exp(-t * 6f) * amp;
            }
        }

        static void Kick(float[] d, float start, float amp)
        {
            int s = (int)(start * SR), n = (int)(0.14f * SR); float ph = 0f;
            for (int i = 0; i < n; i++)
            {
                int idx = s + i; if (idx >= d.Length) break;
                float t = i / (float)n;
                ph += 2f * Mathf.PI * Mathf.Lerp(130f, 45f, t) / SR;
                d[idx] += Mathf.Sin(ph) * (1f - t) * amp;
            }
        }

        static void Tick(float[] d, float start, float amp, System.Random r)
        {
            int s = (int)(start * SR), n = (int)(0.03f * SR);
            for (int i = 0; i < n; i++)
            {
                int idx = s + i; if (idx >= d.Length) break;
                d[idx] += ((float)r.NextDouble() * 2f - 1f) * amp * (1f - i / (float)n);
            }
        }

        AudioClip BuildMusic()
        {
            float beat = 60f / 108f; int bars = 8;
            int total = (int)(bars * 4 * beat * SR);
            float[] d = new float[total];
            float[] bass = { 110f, 87.31f, 130.81f, 98f, 110f, 87.31f, 98f, 110f };
            float[] scale = { 440f, 523.25f, 587.33f, 659.25f, 783.99f, 880f };
            System.Random r = new System.Random(42);
            for (int bar = 0; bar < bars; bar++)
            {
                float t0 = bar * 4 * beat;
                Marimba(d, t0, beat * 1.5f, bass[bar], 0.30f);
                Marimba(d, t0 + beat * 2f, beat * 1.0f, bass[bar], 0.24f);
                Marimba(d, t0 + beat * 3.5f, beat * 0.5f, bass[bar] * 2f, 0.14f);
                for (int b = 0; b < 4; b++) Kick(d, t0 + b * beat, 0.28f);
                for (int e = 0; e < 8; e++)
                {
                    float te = t0 + e * beat * 0.5f;
                    Tick(d, te, (e % 2 == 1) ? 0.10f : 0.05f, r);
                    if (r.NextDouble() < 0.65) Marimba(d, te, beat * 0.9f, scale[r.Next(scale.Length)], 0.16f);
                }
            }
            float peak = 0.01f;
            for (int i = 0; i < d.Length; i++) peak = Mathf.Max(peak, Mathf.Abs(d[i]));
            float g = 0.7f / peak;
            for (int i = 0; i < d.Length; i++) d[i] *= g;
            return Make("jungle_music", d);
        }
    }
}
