using UnityEngine;
using UnityEngine.UI;

namespace JungleRunner
{
    /// <summary>In-run HUD: coins, score, distance, active power-up indicators, pause button.</summary>
    public class GameplayUI : MonoBehaviour
    {
        Text coinText, scoreText, distText, multText;
        RectTransform[] puRoots = new RectTransform[4];
        Text[] puTexts = new Text[4];
        RectTransform[] puBars = new RectTransform[4];
        GameObject hudRoot;
        int lastCoins = -1, lastScore = -1, lastDist = -1;
        static readonly PowerUpType[] timed = { PowerUpType.Magnet, PowerUpType.Shield, PowerUpType.SpeedBoost, PowerUpType.ScoreMultiplier };

        public void Build()
        {
            Canvas canvas = UIBuilder.CreateCanvas("HUDCanvas", 1);
            hudRoot = canvas.gameObject;
            Transform root = canvas.transform;

            Image coinBox = UIBuilder.Box(root, "CoinBox", new Color(0, 0.1f, 0, 0.55f), true);
            UIBuilder.Anchor(coinBox.rectTransform, new Vector2(0, 1), new Vector2(30, -30), new Vector2(320, 100));
            Image icon = UIBuilder.Box(coinBox.transform, "Icon", new Color(1f, 0.8f, 0.1f), false);
            icon.sprite = UIBuilder.Circle;
            UIBuilder.Anchor(icon.rectTransform, new Vector2(0, 0.5f), new Vector2(15, 0), new Vector2(70, 70));
            coinText = UIBuilder.Label(coinBox.transform, "0", 56, UIBuilder.Gold);
            UIBuilder.Anchor(coinText.rectTransform, new Vector2(1, 0.5f), new Vector2(-20, 0), new Vector2(210, 90));
            coinText.alignment = TextAnchor.MiddleRight;

            Text sl = UIBuilder.Label(root, "SCORE", 34, new Color(0.85f, 1f, 0.8f));
            UIBuilder.Anchor(sl.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -18), new Vector2(300, 44));
            scoreText = UIBuilder.Label(root, "0", 90, Color.white);
            UIBuilder.Anchor(scoreText.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -55), new Vector2(600, 110));
            distText = UIBuilder.Label(root, "0 m", 42, new Color(0.9f, 1f, 0.85f));
            UIBuilder.Anchor(distText.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -170), new Vector2(400, 56));
            multText = UIBuilder.Label(root, "", 40, UIBuilder.Gold);
            UIBuilder.Anchor(multText.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -225), new Vector2(400, 50));

            Button pause = UIBuilder.MakeButton(root, "II", UIBuilder.Brown, 56, () => { if (GameManager.Instance != null) GameManager.Instance.Pause(); });
            UIBuilder.Anchor(pause.GetComponent<RectTransform>(), new Vector2(1, 1), new Vector2(-30, -30), new Vector2(110, 110));

            for (int i = 0; i < timed.Length; i++)
            {
                Image bg = UIBuilder.Box(root, "PU_" + timed[i], new Color(0, 0.1f, 0, 0.6f), true);
                UIBuilder.Anchor(bg.rectTransform, new Vector2(0, 1), new Vector2(30, -150 - i * 100), new Vector2(420, 84));
                puRoots[i] = bg.rectTransform;
                Image strip = UIBuilder.Box(bg.transform, "Strip", PowerUpManager.Colors[(int)timed[i]], true);
                UIBuilder.Anchor(strip.rectTransform, new Vector2(0, 0.5f), new Vector2(8, 0), new Vector2(14, 64));
                puTexts[i] = UIBuilder.Label(bg.transform, "", 32, Color.white);
                UIBuilder.Anchor(puTexts[i].rectTransform, new Vector2(0, 1), new Vector2(34, -6), new Vector2(380, 44));
                puTexts[i].alignment = TextAnchor.MiddleLeft;
                Image bar = UIBuilder.Box(bg.transform, "Bar", PowerUpManager.Colors[(int)timed[i]], true);
                UIBuilder.Anchor(bar.rectTransform, new Vector2(0, 0), new Vector2(34, 10), new Vector2(370, 14));
                puBars[i] = bar.rectTransform;
                bg.gameObject.SetActive(false);
            }
            GameManager gm = GameManager.Instance;
            if (gm != null) { gm.OnRunEnded += HideHud; gm.OnRevived += ShowHud; }
        }

        void OnDestroy()
        {
            GameManager gm = GameManager.Instance;
            if (gm != null) { gm.OnRunEnded -= HideHud; gm.OnRevived -= ShowHud; }
        }

        void HideHud() { if (hudRoot != null) hudRoot.SetActive(false); }
        void ShowHud() { if (hudRoot != null) hudRoot.SetActive(true); }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || ScoreManager.Instance == null || CoinManager.Instance == null) return;
            int c = CoinManager.Instance.RunCoins, s = ScoreManager.Instance.Score, d = (int)gm.Distance;
            if (c != lastCoins) { lastCoins = c; coinText.text = c.ToString(); }
            if (s != lastScore) { lastScore = s; scoreText.text = s.ToString(); }
            if (d != lastDist) { lastDist = d; distText.text = d + " m"; }
            int mult = ScoreManager.Instance.Multiplier;
            string mt = mult > 1 ? "x" + mult + " SCORE!" : "";
            if (multText.text != mt) multText.text = mt;
            PowerUpManager pm = PowerUpManager.Instance;
            for (int i = 0; i < timed.Length; i++)
            {
                bool on = pm != null && pm.IsActive(timed[i]);
                if (puRoots[i].gameObject.activeSelf != on) puRoots[i].gameObject.SetActive(on);
                if (!on) continue;
                float rem = pm.Remaining(timed[i]);
                puTexts[i].text = PowerUpManager.Names[(int)timed[i]] + (timed[i] == PowerUpType.Shield ? "" : "  " + rem.ToString("0.0") + "s");
                puBars[i].sizeDelta = new Vector2(370f * Mathf.Clamp01(rem / PowerUpManager.Duration(timed[i])), 14f);
            }
        }
    }
}
