using UnityEngine;
using UnityEngine.UI;

namespace JungleRunner
{
    public class PauseMenuUI : MonoBehaviour
    {
        GameObject root;
        Text soundText;

        public void Build()
        {
            Canvas canvas = UIBuilder.CreateCanvas("PauseCanvas", 10);
            Image dim = UIBuilder.Box(canvas.transform, "Dim", new Color(0, 0, 0, 0.65f), false);
            UIBuilder.Stretch(dim.rectTransform);
            root = dim.gameObject;
            Image panel = UIBuilder.Box(dim.transform, "Panel", UIBuilder.Panel, true);
            UIBuilder.Anchor(panel.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(720, 860));
            Text t = UIBuilder.Label(panel.transform, "PAUSED", 80, UIBuilder.Gold);
            UIBuilder.Anchor(t.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -40), new Vector2(600, 100));
            AddButton(panel.transform, "RESUME", UIBuilder.Green, -170, () => GameManager.Instance.Resume());
            AddButton(panel.transform, "RESTART", UIBuilder.Brown, -320, () => GameManager.Instance.Restart());
            AddButton(panel.transform, "HOME", UIBuilder.Brown, -470, () => GameManager.Instance.GoHome());
            Button s = AddButton(panel.transform, "", UIBuilder.Brown, -620, ToggleSound);
            soundText = s.GetComponentInChildren<Text>();
            root.SetActive(false);
            GameManager gm = GameManager.Instance;
            gm.OnPaused += Show; gm.OnResumed += Hide; gm.OnRunEnded += Hide;
        }

        void OnDestroy()
        {
            GameManager gm = GameManager.Instance;
            if (gm != null) { gm.OnPaused -= Show; gm.OnResumed -= Hide; gm.OnRunEnded -= Hide; }
        }

        Button AddButton(Transform parent, string label, Color c, float y, UnityEngine.Events.UnityAction a)
        {
            Button b = UIBuilder.MakeButton(parent, label, c, 52, a);
            UIBuilder.Anchor(b.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(0, y), new Vector2(520, 120));
            return b;
        }

        void ToggleSound() { AudioManager.Instance.SetSound(!AudioManager.Instance.SoundOn); Refresh(); }
        void Refresh() { soundText.text = "SOUND: " + (AudioManager.Instance != null && AudioManager.Instance.SoundOn ? "ON" : "OFF"); }
        void Show() { Refresh(); root.SetActive(true); }
        void Hide() { root.SetActive(false); }
    }
}
