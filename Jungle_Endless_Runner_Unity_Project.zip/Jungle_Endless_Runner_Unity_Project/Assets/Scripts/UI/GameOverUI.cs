using UnityEngine;
using UnityEngine.UI;

namespace JungleRunner
{
    public class GameOverUI : MonoBehaviour
    {
        GameObject root;
        Text scoreText, bestText, coinText, reviveText;
        Button reviveBtn;

        public void Build()
        {
            Canvas canvas = UIBuilder.CreateCanvas("GameOverCanvas", 11);
            Image dim = UIBuilder.Box(canvas.transform, "Dim", new Color(0, 0, 0, 0.7f), false);
            UIBuilder.Stretch(dim.rectTransform);
            root = dim.gameObject;
            Image panel = UIBuilder.Box(dim.transform, "Panel", UIBuilder.Panel, true);
            UIBuilder.Anchor(panel.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(900, 940));
            Text t = UIBuilder.Label(panel.transform, "GAME OVER", 100, new Color(1f, 0.35f, 0.3f));
            UIBuilder.Anchor(t.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -40), new Vector2(800, 120));
            scoreText = Line(panel.transform, -190, 60, Color.white);
            bestText = Line(panel.transform, -280, 46, UIBuilder.Gold);
            coinText = Line(panel.transform, -360, 46, UIBuilder.Gold);
            reviveBtn = UIBuilder.MakeButton(panel.transform, "", UIBuilder.Green, 46, () =>
            {
                if (GameOverManager.Instance.TryRevive()) root.SetActive(false);
            });
            reviveText = reviveBtn.GetComponentInChildren<Text>();
            UIBuilder.Anchor(reviveBtn.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(0, -450), new Vector2(640, 120));
            Button retry = UIBuilder.MakeButton(panel.transform, "RETRY", UIBuilder.Brown, 50, () => GameManager.Instance.Restart());
            UIBuilder.Anchor(retry.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(-170, -610), new Vector2(320, 120));
            Button home = UIBuilder.MakeButton(panel.transform, "HOME", UIBuilder.Brown, 50, () => GameManager.Instance.GoHome());
            UIBuilder.Anchor(home.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(170, -610), new Vector2(320, 120));
            root.SetActive(false);
            GameOverManager.Instance.OnShowScreen += Show;
        }

        Text Line(Transform p, float y, int size, Color c)
        {
            Text t = UIBuilder.Label(p, "", size, c);
            UIBuilder.Anchor(t.rectTransform, new Vector2(0.5f, 1), new Vector2(0, y), new Vector2(800, size + 20));
            return t;
        }

        void OnDestroy() { if (GameOverManager.Instance != null) GameOverManager.Instance.OnShowScreen -= Show; }

        void Show()
        {
            GameOverManager gom = GameOverManager.Instance;
            scoreText.text = "SCORE: " + ScoreManager.Instance.Score;
            bestText.text = gom.IsNewBest ? "NEW BEST SCORE!" : "BEST: " + ScoreManager.Instance.BestScore;
            coinText.text = "COINS COLLECTED: " + CoinManager.Instance.RunCoins;
            bool can = gom.CanRevive;
            reviveBtn.interactable = can;
            reviveText.text = GameManager.Instance.RevivesUsed > 0 ? "REVIVE USED" : (can ? "REVIVE  (" + GameOverManager.ReviveCost + " coins)" : "REVIVE (need " + GameOverManager.ReviveCost + " coins)");
            reviveBtn.GetComponent<Image>().color = can ? UIBuilder.Green : new Color(0.4f, 0.4f, 0.4f);
            root.SetActive(true);
        }
    }
}
