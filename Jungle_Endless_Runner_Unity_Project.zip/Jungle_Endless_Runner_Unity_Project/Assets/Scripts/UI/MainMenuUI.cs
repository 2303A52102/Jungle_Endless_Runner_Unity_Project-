using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace JungleRunner
{
    public class MainMenuUI : MonoBehaviour
    {
        Text bestText, coinsText, soundText, soundTextMenu, musicText, resetText;
        GameObject settings;
        bool resetArmed;

        public void Build()
        {
            UIBuilder.EnsureEventSystem();
            Transform root = UIBuilder.CreateCanvas("MenuCanvas", 0).transform;

            Text title = UIBuilder.Label(root, "JUNGLE ENDLESS RUNNER", 104, UIBuilder.Gold);
            UIBuilder.Anchor(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -40), new Vector2(1700, 150));
            Text sub = UIBuilder.Label(root, "RUN  •  JUMP  •  SLIDE  •  SURVIVE", 40, new Color(0.85f, 1f, 0.8f));
            UIBuilder.Anchor(sub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -190), new Vector2(1200, 60));

            Image stats = UIBuilder.Box(root, "Stats", new Color(0f, 0.12f, 0f, 0.6f), true);
            UIBuilder.Anchor(stats.rectTransform, new Vector2(0, 0), new Vector2(40, 40), new Vector2(560, 220));
            bestText = UIBuilder.Label(stats.transform, "", 48, Color.white);
            UIBuilder.Anchor(bestText.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -30), new Vector2(520, 70));
            coinsText = UIBuilder.Label(stats.transform, "", 48, UIBuilder.Gold);
            UIBuilder.Anchor(coinsText.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -115), new Vector2(520, 70));

            Button play = UIBuilder.MakeButton(root, "PLAY", UIBuilder.Green, 72, OnPlay);
            UIBuilder.Anchor(play.GetComponent<RectTransform>(), new Vector2(1, 0.5f), new Vector2(-120, 110), new Vector2(480, 150));
            Button set = UIBuilder.MakeButton(root, "SETTINGS", UIBuilder.Brown, 48, () => { settings.SetActive(true); Refresh(); });
            UIBuilder.Anchor(set.GetComponent<RectTransform>(), new Vector2(1, 0.5f), new Vector2(-120, -70), new Vector2(480, 110));
            Button snd = UIBuilder.MakeButton(root, "", UIBuilder.Brown, 40, ToggleSound);
            soundTextMenu = snd.GetComponentInChildren<Text>();
            UIBuilder.Anchor(snd.GetComponent<RectTransform>(), new Vector2(1, 0.5f), new Vector2(-120, -200), new Vector2(480, 100));
#if !UNITY_ANDROID && !UNITY_IOS
            Button quit = UIBuilder.MakeButton(root, "QUIT", UIBuilder.Red, 36, Application.Quit);
            UIBuilder.Anchor(quit.GetComponent<RectTransform>(), new Vector2(1, 1), new Vector2(-30, -30), new Vector2(180, 80));
#endif
            BuildSettings(root);
            Refresh();
        }

        void BuildSettings(Transform root)
        {
            Image dim = UIBuilder.Box(root, "SettingsDim", new Color(0, 0, 0, 0.6f), false);
            UIBuilder.Stretch(dim.rectTransform);
            settings = dim.gameObject;
            Image panel = UIBuilder.Box(dim.transform, "Panel", UIBuilder.Panel, true);
            UIBuilder.Anchor(panel.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(800, 760));
            Text t = UIBuilder.Label(panel.transform, "SETTINGS", 68, UIBuilder.Gold);
            UIBuilder.Anchor(t.rectTransform, new Vector2(0.5f, 1), new Vector2(0, -40), new Vector2(700, 90));
            Button s = UIBuilder.MakeButton(panel.transform, "", UIBuilder.Brown, 44, ToggleSound); soundText = s.GetComponentInChildren<Text>();
            UIBuilder.Anchor(s.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(0, -170), new Vector2(600, 110));
            Button m = UIBuilder.MakeButton(panel.transform, "", UIBuilder.Brown, 44, ToggleMusic); musicText = m.GetComponentInChildren<Text>();
            UIBuilder.Anchor(m.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(0, -310), new Vector2(600, 110));
            Button r = UIBuilder.MakeButton(panel.transform, "", UIBuilder.Red, 40, ResetData); resetText = r.GetComponentInChildren<Text>();
            UIBuilder.Anchor(r.GetComponent<RectTransform>(), new Vector2(0.5f, 1), new Vector2(0, -450), new Vector2(600, 110));
            Button c = UIBuilder.MakeButton(panel.transform, "CLOSE", UIBuilder.Green, 48, () => { settings.SetActive(false); resetArmed = false; Refresh(); });
            UIBuilder.Anchor(c.GetComponent<RectTransform>(), new Vector2(0.5f, 0), new Vector2(0, 50), new Vector2(400, 110));
            settings.SetActive(false);
        }

        void Refresh()
        {
            bestText.text = "BEST SCORE: " + SaveData.BestScore;
            coinsText.text = "COINS: " + SaveData.TotalCoins;
            AudioManager am = AudioManager.Instance;
            bool snd = am != null ? am.SoundOn : SaveData.SoundOn, mus = am != null ? am.MusicOn : SaveData.MusicOn;
            soundText.text = "SOUND: " + (snd ? "ON" : "OFF");
            soundTextMenu.text = soundText.text;
            musicText.text = "MUSIC: " + (mus ? "ON" : "OFF");
            resetText.text = resetArmed ? "TAP AGAIN TO CONFIRM" : "RESET SAVED DATA";
        }

        void ToggleSound() { if (AudioManager.Instance != null) AudioManager.Instance.SetSound(!AudioManager.Instance.SoundOn); Refresh(); }
        void ToggleMusic() { if (AudioManager.Instance != null) AudioManager.Instance.SetMusic(!AudioManager.Instance.MusicOn); Refresh(); }
        void ResetData() { if (!resetArmed) { resetArmed = true; } else { SaveData.ResetProgress(); resetArmed = false; } Refresh(); }
        void OnPlay() { SceneManager.LoadScene("Gameplay"); }
    }
}
