using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace JungleRunner
{
    /// <summary>Code-built uGUI helpers (rounded sprites, labels, buttons). No UI asset dependencies.</summary>
    public static class UIBuilder
    {
        static Font font;
        static Sprite rounded, circle;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { font = null; rounded = null; circle = null; }

        public static Font DefaultFont
        {
            get
            {
                if (font == null)
                {
#if UNITY_2022_2_OR_NEWER
                    font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                    font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                    if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 16);
                }
                return font;
            }
        }

        static Sprite MakeSprite(bool isCircle)
        {
            int s = 64; float r = isCircle ? 32f : 22f;
            Texture2D tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear; tex.wrapMode = TextureWrapMode.Clamp;
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++)
                {
                    float dx = Mathf.Max(r - x - 0.5f, 0f, x + 0.5f - (s - r));
                    float dy = Mathf.Max(r - y - 0.5f, 0f, y + 0.5f - (s - r));
                    float a = Mathf.Clamp01(r - Mathf.Sqrt(dx * dx + dy * dy) + 0.5f);
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(r, r, r, r));
        }

        public static Sprite Rounded { get { if (rounded == null) rounded = MakeSprite(false); return rounded; } }
        public static Sprite Circle { get { if (circle == null) circle = MakeSprite(true); return circle; } }

        public static Canvas CreateCanvas(string name, int order)
        {
            GameObject go = new GameObject(name);
            Canvas c = go.AddComponent<Canvas>();
            c.renderMode = RenderMode.ScreenSpaceOverlay; c.sortingOrder = order;
            CanvasScaler cs = go.AddComponent<CanvasScaler>();
            cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            cs.referenceResolution = new Vector2(1920, 1080);
            cs.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            cs.matchWidthOrHeight = 0.5f;
            go.AddComponent<GraphicRaycaster>();
            return c;
        }

        public static void EnsureEventSystem()
        {
            if (Object.FindObjectOfType<EventSystem>() != null) return;
            GameObject go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
        }

        public static RectTransform Anchor(RectTransform r, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            r.anchorMin = anchor; r.anchorMax = anchor; r.pivot = anchor;
            r.anchoredPosition = pos; r.sizeDelta = size;
            return r;
        }

        public static void Stretch(RectTransform r) { r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one; r.offsetMin = Vector2.zero; r.offsetMax = Vector2.zero; }

        public static Image Box(Transform parent, string name, Color color, bool round)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            Image img = go.AddComponent<Image>();
            img.color = color;
            if (round) { img.sprite = Rounded; img.type = Image.Type.Sliced; }
            return img;
        }

        public static Text Label(Transform parent, string text, int size, Color color)
        {
            GameObject go = new GameObject("Text", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            Text t = go.AddComponent<Text>();
            t.font = DefaultFont; t.text = text; t.fontSize = size; t.color = color;
            t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
            t.horizontalOverflow = HorizontalWrapMode.Overflow; t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            Outline o = go.AddComponent<Outline>();
            o.effectColor = new Color(0.05f, 0.15f, 0.05f, 0.9f); o.effectDistance = new Vector2(3f, -3f);
            return t;
        }

        public static Button MakeButton(Transform parent, string label, Color color, int fontSize, UnityAction onClick)
        {
            Image img = Box(parent, "Button_" + label, color, true);
            Button b = img.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white; cb.highlightedColor = new Color(1f, 1f, 1f, 1f);
            cb.pressedColor = new Color(0.75f, 0.75f, 0.75f, 1f); cb.selectedColor = Color.white;
            cb.fadeDuration = 0.05f;
            b.colors = cb;
            Text t = Label(img.transform, label, fontSize, Color.white);
            Stretch(t.rectTransform);
            b.onClick.AddListener(() => { AudioManager.Play(Sfx.Click); if (onClick != null) onClick(); });
            return b;
        }

        public static readonly Color Green = new Color(0.22f, 0.62f, 0.2f);
        public static readonly Color Brown = new Color(0.55f, 0.36f, 0.16f);
        public static readonly Color Gold = new Color(1f, 0.85f, 0.25f);
        public static readonly Color Red = new Color(0.8f, 0.22f, 0.18f);
        public static readonly Color Panel = new Color(0.05f, 0.18f, 0.07f, 0.88f);
    }
}
