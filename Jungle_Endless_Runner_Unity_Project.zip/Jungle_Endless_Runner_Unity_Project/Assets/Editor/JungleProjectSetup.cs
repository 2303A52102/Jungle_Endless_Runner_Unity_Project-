#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace JungleRunner.EditorTools
{
    /// <summary>Runs automatically the first time the project opens: creates scenes, shader-holder materials,
    /// Build Settings, mobile player settings and exports reference prefabs.
    /// Re-run any time via  Jungle Runner > Regenerate Project.</summary>
    [InitializeOnLoad]
    public static class JungleProjectSetup
    {
        const string MenuScene = "Assets/Scenes/MainMenu.unity";
        const string GameScene = "Assets/Scenes/Gameplay.unity";

        static JungleProjectSetup() { EditorApplication.delayCall += AutoSetup; }

        static void AutoSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) return;
            if (!File.Exists(MenuScene) || !File.Exists(GameScene)) Generate();
        }

        [MenuItem("Jungle Runner/Regenerate Project (scenes, settings, prefabs)")]
        public static void Generate()
        {
            CreateShaderHolders();
            ConfigurePlayerSettings();
            CreateScene(MenuScene, GameBootstrap.Mode.Menu);
            CreateScene(GameScene, GameBootstrap.Mode.Gameplay);
            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MenuScene, true),
                new EditorBuildSettingsScene(GameScene, true)
            };
            try { ExportPrefabs(); } catch (System.Exception e) { Debug.LogWarning("Prefab export skipped: " + e.Message); }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorSceneManager.OpenScene(MenuScene);
            Debug.Log("[Jungle Runner] Project generated. Open Assets/Scenes/MainMenu.unity and press Play.");
        }

        static void CreateScene(string path, GameBootstrap.Mode mode)
        {
            Directory.CreateDirectory("Assets/Scenes");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject go = new GameObject("GameBootstrap");
            go.AddComponent<GameBootstrap>().mode = mode;
            EditorSceneManager.SaveScene(scene, path);
        }

        // Materials in Resources/ShaderHolders force Unity to include the shaders AND the keyword variants
        // (emission / fade) that the runtime-created materials rely on.
        static void CreateShaderHolders()
        {
            Directory.CreateDirectory("Assets/Resources/ShaderHolders");
            Shader std = Shader.Find("Standard");
            if (std != null)
            {
                Holder("Std", std, null);
                Holder("StdEmission", std, m => { m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor", Color.white); });
                Holder("StdFade", std, m =>
                {
                    m.SetFloat("_Mode", 2);
                    m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                    m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    m.SetInt("_ZWrite", 0);
                    m.EnableKeyword("_ALPHABLEND_ON");
                    m.renderQueue = 3000;
                });
            }
            Shader spr = Shader.Find("Sprites/Default");
            if (spr != null) Holder("Sprite", spr, null);
            Shader sky = Shader.Find("Skybox/Procedural");
            if (sky != null) Holder("Sky", sky, null);
        }

        static void Holder(string name, Shader s, System.Action<Material> setup)
        {
            string path = "Assets/Resources/ShaderHolders/" + name + ".mat";
            if (File.Exists(path)) return;
            Material m = new Material(s);
            if (setup != null) setup(m);
            AssetDatabase.CreateAsset(m, path);
        }

        static void ConfigurePlayerSettings()
        {
            PlayerSettings.companyName = "JungleGames";
            PlayerSettings.productName = "Jungle Endless Runner";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
#pragma warning disable 618
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.junglegames.junglerunner");
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
#pragma warning restore 618
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
        }

        // ------------------------------------------------------------ prefab export (reference copies)
        static void ExportPrefabs()
        {
            foreach (ObstacleType t in System.Enum.GetValues(typeof(ObstacleType)))
                Save(ObstacleFactory.Build(t), "Assets/Prefabs/Obstacles/" + t + ".prefab");
            Save(CoinFactory.Build(), "Assets/Prefabs/Coins/Coin.prefab");
            foreach (PowerUpType t in System.Enum.GetValues(typeof(PowerUpType)))
                Save(PowerUpFactory.Build(t), "Assets/Prefabs/PowerUps/" + t + ".prefab");
            GameObject player = new GameObject("Player");
            PlayerFactory.BuildModel(player.transform);
            Save(player, "Assets/Prefabs/Player/PlayerModel.prefab");
        }

        static void Save(GameObject go, string path)
        {
            foreach (Renderer r in go.GetComponentsInChildren<Renderer>())
            {
                Material[] mats = r.sharedMaterials;
                for (int i = 0; i < mats.Length; i++) mats[i] = SaveMaterial(mats[i]);
                r.sharedMaterials = mats;
            }
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }

        static Material SaveMaterial(Material src)
        {
            if (src == null) return null;
            string clean = src.name.Replace(" ", "_").Replace("/", "_");
            string path = "Assets/Materials/" + clean + ".mat";
            Material existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing != null) return existing;
            AssetDatabase.CreateAsset(new Material(src), path);
            return AssetDatabase.LoadAssetAtPath<Material>(path);
        }

        // ------------------------------------------------------------ builds
        [MenuItem("Jungle Runner/Build/Windows (.exe)")]
        public static void BuildWindows() { Build(BuildTarget.StandaloneWindows64, "Builds/Windows/JungleEndlessRunner.exe"); }

        [MenuItem("Jungle Runner/Build/Android (.apk)")]
        public static void BuildAndroid() { Build(BuildTarget.Android, "Builds/Android/JungleEndlessRunner.apk"); }

        static void Build(BuildTarget target, string path)
        {
            if (!File.Exists(MenuScene) || !File.Exists(GameScene)) Generate();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            BuildPlayerOptions o = new BuildPlayerOptions();
            o.scenes = new[] { MenuScene, GameScene };
            o.locationPathName = path;
            o.target = target;
            o.options = BuildOptions.None;
            BuildPipeline.BuildPlayer(o);
        }
    }
}
#endif
